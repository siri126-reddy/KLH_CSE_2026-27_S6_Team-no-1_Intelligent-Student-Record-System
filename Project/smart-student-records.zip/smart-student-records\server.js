const express = require('express');
const cors = require('cors');
const path = require('path');
const studentService = require('./src/services/studentService');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// ---------------- API ROUTES ----------------

// Authentication: Login for Admin and Student Portals
app.post('/api/auth/login', (req, res) => {
  try {
    const { role, identifier, password } = req.body;
    if (!identifier || !password) {
      return res.status(400).json({ success: false, error: 'Identifier (Username/Roll No) and password are required' });
    }

    const authResult = studentService.authenticate(role, identifier, password);
    if (!authResult.success) {
      return res.status(401).json(authResult);
    }

    res.json(authResult);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Demo Credentials for quick 1-click testing
app.get('/api/auth/demo-credentials', (req, res) => {
  try {
    const students = studentService.getAllStudents();
    const demoStudents = students.slice(0, 3).map(s => ({
      name: s.name,
      rollNo: s.rollNo,
      department: s.department,
      cgpa: s.cgpa,
      defaultPassword: 'student123'
    }));

    res.json({
      success: true,
      admin: {
        username: 'admin',
        password: 'admin123',
        description: 'Full Administrative Privileges (CRUD, DSA Lab, Benchmarks, Analytics)'
      },
      students: demoStudents
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Dashboard Stats & DSA Overview
app.get('/api/stats', (req, res) => {
  try {
    const stats = studentService.getDashboardStats();
    res.json({ success: true, data: stats });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// All Students with optional filters
app.get('/api/students', (req, res) => {
  try {
    const students = studentService.getAllStudents(req.query);
    res.json({ success: true, count: students.length, data: students });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get Single Student
app.get('/api/students/:id', (req, res) => {
  try {
    const student = studentService.getStudentById(req.params.id);
    if (!student) {
      return res.status(404).json({ success: false, error: 'Student not found' });
    }
    res.json({ success: true, data: student });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Add New Student (CRUD: Create)
app.post('/api/students', (req, res) => {
  try {
    const { name, rollNo, department } = req.body;
    if (!name || !rollNo) {
      return res.status(400).json({ success: false, error: 'Name and Roll Number are required' });
    }
    const created = studentService.createStudent(req.body);
    res.status(201).json({ success: true, message: 'Student created successfully', data: created });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Update Existing Student (CRUD: Update)
app.put('/api/students/:id', (req, res) => {
  try {
    const updated = studentService.updateStudent(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, error: 'Student not found' });
    }
    res.json({ success: true, message: 'Student updated successfully', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Delete Student (CRUD: Delete)
app.delete('/api/students/:id', (req, res) => {
  try {
    const deleted = studentService.deleteStudent(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, error: 'Student not found' });
    }
    res.json({ success: true, message: 'Student deleted successfully', data: deleted });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ---------------- ADVANCED DSA SEARCH ENDPOINTS ----------------

// 1. Auto-complete endpoint using Trie
app.get('/api/autocomplete', (req, res) => {
  try {
    const query = req.query.q || '';
    const limit = parseInt(req.query.limit, 10) || 8;
    const result = studentService.autocomplete(query, limit);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Smart Search with Relevance Ranking
app.get('/api/search', (req, res) => {
  try {
    const query = req.query.q || '';
    const result = studentService.smartSearch(query, req.query);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Fuzzy Search using Levenshtein Distance
app.get('/api/dsa/fuzzy', (req, res) => {
  try {
    const query = req.query.q || '';
    const threshold = parseInt(req.query.threshold, 10) || 2;
    const result = studentService.fuzzySearch(query, threshold);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Pattern Search using Knuth-Morris-Pratt (KMP)
app.get('/api/dsa/kmp', (req, res) => {
  try {
    const pattern = req.query.pattern || '';
    const fields = req.query.fields ? req.query.fields.split(',') : undefined;
    const result = studentService.kmpSearch(pattern, fields);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. Similarity Matching using Jaccard & Cosine Similarity
app.get('/api/dsa/similarity/:id', (req, res) => {
  try {
    const studentId = req.params.id;
    const topK = parseInt(req.query.topK, 10) || 5;
    const result = studentService.findSimilar(studentId, topK);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 6. Benchmark Comparison: Linear Scan vs. Inverted Index
app.get('/api/dsa/benchmark', (req, res) => {
  try {
    const query = req.query.q || '';
    const result = studentService.benchmark(query);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Serve frontend fallback for SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(` Smart Student Record Management & DSA Search System `);
  console.log(` Server running on http://localhost:${PORT}          `);
  console.log(` API & Web Dashboard ready!                         `);
  console.log(`====================================================`);
});
