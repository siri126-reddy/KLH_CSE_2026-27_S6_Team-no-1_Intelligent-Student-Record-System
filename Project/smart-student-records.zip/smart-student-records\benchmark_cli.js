/**
 * Algorithmic Benchmark Suite for Smart Student Record Management
 * Quantifies time complexity and real-world execution speedups:
 * Linear Scan O(N x M) vs Inverted Index O(1)
 */

const studentService = require('./src/services/studentService');

const queries = [
  'Python',
  'Machine Learning',
  'Docker',
  'Algorithms',
  'React',
  'Robotics',
  'VLSI',
  'FastAPI'
];

console.log('========================================================================================');
console.log('       COMPREHENSIVE ALGORITHMIC BENCHMARK: LINEAR SCAN vs. INVERTED INDEX              ');
console.log('========================================================================================');
console.log(`Database Size: ${studentService.getAllStudents().length} student records`);
console.log(`Indexed Terms: ${studentService.invertedIndex.totalIndexedTerms} terms in Inverted Index`);
console.log('----------------------------------------------------------------------------------------\n');

const results = [];
let totalLinearMicroseconds = 0;
let totalIndexMicroseconds = 0;
let totalLinearComparisons = 0;
let totalIndexComparisons = 0;

for (const q of queries) {
  const b = studentService.benchmark(q);
  totalLinearMicroseconds += b.linearScan.timeMicroseconds;
  totalIndexMicroseconds += b.invertedIndex.timeMicroseconds;
  totalLinearComparisons += b.linearScan.comparisons;
  totalIndexComparisons += b.invertedIndex.comparisons;

  results.push({
    query: q,
    linearTime: b.linearScan.timeMicroseconds,
    linearComps: b.linearScan.comparisons,
    indexTime: b.invertedIndex.timeMicroseconds,
    indexComps: b.invertedIndex.comparisons,
    matches: b.invertedIndex.matchesCount,
    speedup: b.speedupMultiplier
  });
}

// Print Formatted Table
console.log(
  '| ' + 'Query Token'.padEnd(18) +
  '| ' + 'Matches'.padEnd(8) +
  '| ' + 'Linear Time'.padEnd(14) +
  '| ' + 'Linear Comps'.padEnd(14) +
  '| ' + 'Index Time'.padEnd(13) +
  '| ' + 'Index Comps'.padEnd(13) +
  '| ' + 'Speedup'.padEnd(10) + '|'
);
console.log('|' + '-'.repeat(98) + '|');

for (const r of results) {
  console.log(
    '| ' + r.query.padEnd(18) +
    '| ' + String(r.matches).padEnd(8) +
    '| ' + (r.linearTime + ' us').padEnd(14) +
    '| ' + String(r.linearComps).padEnd(14) +
    '| ' + (r.indexTime + ' us').padEnd(13) +
    '| ' + String(r.indexComps).padEnd(13) +
    '| ' + (r.speedup + 'x').padEnd(10) + '|'
  );
}
console.log('|' + '-'.repeat(98) + '|');

const overallSpeedup = totalIndexMicroseconds > 0
  ? (totalLinearMicroseconds / totalIndexMicroseconds).toFixed(1)
  : 'N/A';

console.log('\n================================== BENCHMARK SUMMARY ==================================');
console.log(`Total Linear Scan Time:       ${totalLinearMicroseconds.toFixed(1)} us (${totalLinearComparisons} comparisons)`);
console.log(`Total Inverted Index Time:    ${totalIndexMicroseconds.toFixed(1)} us (${totalIndexComparisons} hash lookups)`);
console.log(`Comparisons Saved by Index:   ${totalLinearComparisons - totalIndexComparisons} string comparisons avoided`);
console.log(`Average Algorithmic Speedup:  ${overallSpeedup}x Faster with Inverted Index!`);
console.log('========================================================================================\n');
