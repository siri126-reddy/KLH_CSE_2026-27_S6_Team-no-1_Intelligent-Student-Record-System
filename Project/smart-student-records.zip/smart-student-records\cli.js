#!/usr/bin/env node
/**
 * Interactive Terminal CLI for Smart Student Record Management & DSA Search System
 * Can run as an interactive REPL or accept one-shot command-line arguments:
 *   node cli.js search "Python"
 *   node cli.js autocomplete "Rup"
 *   node cli.js fuzzy "Mchene"
 *   node cli.js kmp "neural"
 *   node cli.js benchmark "Docker"
 *   node cli.js similar STU-1001
 */

const readline = require('readline');
const studentService = require('./src/services/studentService');

// ANSI Color Helpers
const colors = {
  reset: "\x1b[0m",
  bold: "\x1b[1m",
  dim: "\x1b[2m",
  cyan: "\x1b[36m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  magenta: "\x1b[35m",
  blue: "\x1b[34m",
  red: "\x1b[31m"
};

function banner() {
  console.log(`
${colors.cyan}${colors.bold}========================================================================${colors.reset}
${colors.cyan}${colors.bold} APEX UNIVERSITY - SMART STUDENT RECORD MANAGEMENT & DSA CLI SYSTEM     ${colors.reset}
${colors.dim} Powered by pure Node.js (Trie, Inverted Index, KMP, Levenshtein, Jaccard) ${colors.reset}
${colors.cyan}${colors.bold}========================================================================${colors.reset}
`);
}

// Check for one-shot command line arguments
const args = process.argv.slice(2);
if (args.length > 0) {
  handleCliArg(args);
} else {
  startInteractiveRepl();
}

function handleCliArg(args) {
  banner();
  const command = args[0].toLowerCase();
  const query = args.slice(1).join(' ');

  switch (command) {
    case 'search':
      runSmartSearch(query);
      break;
    case 'autocomplete':
    case 'auto':
      runAutocomplete(query);
      break;
    case 'fuzzy':
      runFuzzySearch(query);
      break;
    case 'kmp':
      runKmpSearch(query);
      break;
    case 'similar':
      runSimilarity(query || 'STU-1001');
      break;
    case 'benchmark':
    case 'bench':
      runBenchmark(query || 'Python');
      break;
    case 'portal':
    case 'student':
      runStudentPortal(query || '21CS101');
      break;
    default:
      console.log(`${colors.yellow}Unknown command: ${command}${colors.reset}`);
      console.log(`Usage: node cli.js [portal|search|autocomplete|fuzzy|kmp|similar|benchmark] <query>`);
      break;
  }
}

function startInteractiveRepl() {
  banner();
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  function showMenu() {
    console.log(`${colors.bold}Choose an operation:${colors.reset}`);
    console.log(`  ${colors.green}1.${colors.reset} Smart Search (Multi-Factor Relevance Ranker)`);
    console.log(`  ${colors.green}2.${colors.reset} Trie Autocomplete (Prefix Tree Lookup)`);
    console.log(`  ${colors.green}3.${colors.reset} Fuzzy Search (Levenshtein Distance Typo Tolerance)`);
    console.log(`  ${colors.green}4.${colors.reset} KMP Pattern Search (Zero-Backtrack LPS Matching)`);
    console.log(`  ${colors.green}5.${colors.reset} Find Similar Students (Jaccard & Cosine Vectors)`);
    console.log(`  ${colors.green}6.${colors.reset} Algorithmic Benchmark (Linear Scan vs. Inverted Index)`);
    console.log(`  ${colors.green}7.${colors.reset} List All Student Records`);
    console.log(`  ${colors.green}8.${colors.reset} System & DSA Stats`);
    console.log(`  ${colors.red}9. Exit${colors.reset}`);
    console.log('');

    rl.question(`${colors.cyan}Enter choice (1-9): ${colors.reset}`, (choice) => {
      handleChoice(choice.trim(), rl, showMenu);
    });
  }

  showMenu();
}

function handleChoice(choice, rl, callback) {
  switch (choice) {
    case '1':
      rl.question(`${colors.yellow}Enter search keyword (e.g. Python, Docker, 21CS101, Machine Learning): ${colors.reset}`, (q) => {
        runSmartSearch(q);
        pressAnyKey(rl, callback);
      });
      break;

    case '2':
      rl.question(`${colors.yellow}Enter prefix to autocomplete (e.g. Rup, Mac, Pyt, 21): ${colors.reset}`, (q) => {
        runAutocomplete(q);
        pressAnyKey(rl, callback);
      });
      break;

    case '3':
      rl.question(`${colors.yellow}Enter term with typos (e.g. Mchene, Rupes, Pithon, Dokr): ${colors.reset}`, (q) => {
        runFuzzySearch(q);
        pressAnyKey(rl, callback);
      });
      break;

    case '4':
      rl.question(`${colors.yellow}Enter pattern to match using KMP (e.g. neural, queue, FPGA): ${colors.reset}`, (q) => {
        runKmpSearch(q);
        pressAnyKey(rl, callback);
      });
      break;

    case '5':
      rl.question(`${colors.yellow}Enter Student ID or Roll No (e.g. STU-1001, 21CS101): ${colors.reset}`, (id) => {
        runSimilarity(id || 'STU-1001');
        pressAnyKey(rl, callback);
      });
      break;

    case '6':
      rl.question(`${colors.yellow}Enter benchmark search term (default: Python): ${colors.reset}`, (q) => {
        runBenchmark(q || 'Python');
        pressAnyKey(rl, callback);
      });
      break;

    case '7':
      listAllStudents();
      pressAnyKey(rl, callback);
      break;

    case '8':
      showSystemStats();
      pressAnyKey(rl, callback);
      break;

    case '9':
    case 'exit':
    case 'q':
      console.log(`\n${colors.cyan}Exiting Apex University CLI. Have a great day!${colors.reset}\n`);
      rl.close();
      break;

    default:
      console.log(`${colors.red}Invalid option!${colors.reset}\n`);
      callback();
      break;
  }
}

function pressAnyKey(rl, callback) {
  console.log('');
  rl.question(`${colors.dim}Press ENTER to return to menu...${colors.reset}`, () => {
    console.log('\n------------------------------------------------------------\n');
    callback();
  });
}

function runSmartSearch(query) {
  console.log(`\n${colors.bold}Executing Smart Ranked Search for:${colors.reset} "${colors.yellow}${query}${colors.reset}"`);
  const res = studentService.smartSearch(query);

  console.log(`${colors.dim}Latency: ${res.executionTimeMs} ms | Total Matches: ${res.totalResults} | Algorithm: ${res.algorithm}${colors.reset}\n`);

  if (res.results.length === 0) {
    console.log(`${colors.red}No matching students found.${colors.reset}`);
    return;
  }

  res.results.slice(0, 10).forEach((item, i) => {
    const s = item.student;
    console.log(`${colors.bold}${i + 1}. [${s.rollNo}] ${s.name}${colors.reset} - ${colors.cyan}${s.department}${colors.reset} (Year ${s.year})`);
    console.log(`   CGPA: ${colors.green}${s.cgpa.toFixed(2)}${colors.reset} | Attendance: ${colors.cyan}${s.attendance}%${colors.reset} | Score: ${colors.magenta}${item.score}%${colors.reset}`);
    console.log(`   Skills: ${s.skills.slice(0, 5).join(', ')}`);
    if (item.breakdown && item.breakdown.length > 0) {
      console.log(`   ${colors.dim}Why ranked: ${item.breakdown.map(b => b.reason).join('; ')}${colors.reset}`);
    }
    console.log('');
  });

  if (res.results.length > 10) {
    console.log(`${colors.dim}...and ${res.results.length - 10} more results.${colors.reset}`);
  }
}

function runAutocomplete(prefix) {
  console.log(`\n${colors.bold}Querying Trie Prefix Tree for:${colors.reset} "${colors.yellow}${prefix}${colors.reset}"`);
  const res = studentService.autocomplete(prefix, 10);

  console.log(`${colors.dim}Trie Traversal Time: ${res.executionTimeMs} ms | Total Trie Nodes: ${res.totalWordsInTrie}${colors.reset}\n`);

  if (res.suggestions.length === 0) {
    console.log(`${colors.red}No prefix completions found.${colors.reset}`);
    return;
  }

  res.suggestions.forEach((s, i) => {
    console.log(`  ${colors.green}[${i + 1}]${colors.reset} ${colors.bold}${s.match}${colors.reset} ${colors.dim}(Type: ${s.type}, ID: ${s.studentId})${colors.reset}`);
  });
}

function runFuzzySearch(query) {
  console.log(`\n${colors.bold}Executing Levenshtein Fuzzy Search for typo:${colors.reset} "${colors.yellow}${query}${colors.reset}"`);
  const res = studentService.fuzzySearch(query, 2);

  console.log(`${colors.dim}Dynamic Programming Execution Time: ${res.executionTimeMs} ms | Matches within distance <= 2: ${res.totalMatches}${colors.reset}\n`);

  if (res.results.length === 0) {
    console.log(`${colors.red}No fuzzy matches within threshold.${colors.reset}`);
    return;
  }

  res.results.slice(0, 8).forEach((item, i) => {
    const s = item.student;
    console.log(`  ${colors.green}[${i + 1}]${colors.reset} ${colors.bold}${s.name} (${s.rollNo})${colors.reset} - ${s.department}`);
    console.log(`      Matched Token: "${colors.yellow}${item.matchedTerm}${colors.reset}" in field [${item.field}]`);
    console.log(`      Levenshtein Edit Distance: ${colors.magenta}${item.editDistance}${colors.reset} | Similarity: ${colors.green}${Math.round(item.fuzzyScore * 100)}%${colors.reset}`);
  });
}

function runKmpSearch(pattern) {
  console.log(`\n${colors.bold}Executing KMP Substring Pattern Search for:${colors.reset} "${colors.yellow}${pattern}${colors.reset}"`);
  const res = studentService.kmpSearch(pattern);

  console.log(`${colors.dim}KMP Execution Time: ${res.executionTimeMs} ms | Character Comparisons: ${res.totalComparisons}${colors.reset}`);
  console.log(`Precomputed LPS Array: [${colors.cyan}${res.lps.join(', ')}${colors.reset}]\n`);

  if (res.results.length === 0) {
    console.log(`${colors.red}Pattern not found in any student records.${colors.reset}`);
    return;
  }

  res.results.slice(0, 6).forEach((r, i) => {
    console.log(`  ${colors.green}[${i + 1}]${colors.reset} ${colors.bold}${r.student.name} (${r.student.rollNo})${colors.reset} - ${r.matchCount} occurrence(s)`);
    r.matchDetails.forEach(m => {
      console.log(`      ${colors.cyan}${m.field}:${colors.reset} "${m.snippet.before}${colors.yellow}${colors.bold}${m.snippet.matched}${colors.reset}${m.snippet.after}"`);
    });
  });
}

function runStudentPortal(identifier) {
  const students = studentService.getAllStudents();
  const cleanId = (identifier || '').trim().toLowerCase();
  const s = students.find(st => st.rollNo.toLowerCase() === cleanId || st.id.toLowerCase() === cleanId || st.email.toLowerCase() === cleanId);

  if (!s) {
    console.log(`${colors.red}Student record not found for: "${identifier}"${colors.reset}`);
    return;
  }

  console.log(`
${colors.cyan}========================================================================${colors.reset}
${colors.bold}${colors.green} STUDENT PORTAL - OFFICIAL ACADEMIC DOSSIER (MAINTAINED BY ADMIN)      ${colors.reset}
${colors.cyan}========================================================================${colors.reset}

  ${colors.bold}Name:${colors.reset}        ${s.name}
  ${colors.bold}Roll Number:${colors.reset} ${colors.yellow}${s.rollNo}${colors.reset}
  ${colors.bold}Department:${colors.reset}  ${s.department}
  ${colors.bold}Standing:${colors.reset}    Year ${s.year}, Semester ${s.semester} (Batch 20${s.rollNo.slice(0, 2)})
  ${colors.bold}Record ID:${colors.reset}   ${s.id}

  ${colors.bold}ACADEMIC EVALUATION (ADMIN VERIFIED):${colors.reset}
  - Official CGPA:       ${colors.green}${colors.bold}${s.cgpa.toFixed(2)}${colors.reset} / 10.00 (${s.cgpa >= 9.0 ? 'First Class with Distinction' : 'First Class'})
  - Attendance Status:   ${colors.cyan}${colors.bold}${s.attendance}%${colors.reset} (Exam Clearance Granted)
  - Registered Email:    ${s.email}
  - Registered Phone:    ${s.phone}

  ${colors.bold}VERIFIED TECHNICAL SKILLS:${colors.reset}
  [ ${s.skills.map(sk => colors.cyan + sk + colors.reset).join(', ')} ]

  ${colors.bold}ENGINEERING PROJECTS PORTFOLIO:${colors.reset}`);

  s.projects.forEach((p, idx) => {
    console.log(`  ${colors.magenta}[${idx + 1}] ${p.title}${colors.reset}`);
    console.log(`      ${colors.dim}${p.description}${colors.reset}`);
    if (p.techStack && p.techStack.length > 0) {
      console.log(`      Tech Stack: ${p.techStack.join(', ')}`);
    }
  });

  console.log(`\n  ${colors.bold}HONORS & ACHIEVEMENTS:${colors.reset}`);
  s.achievements.forEach(ach => {
    console.log(`  ${colors.yellow}*${colors.reset} ${ach}`);
  });

  // Peer similarity
  const sim = studentService.findSimilar(s.id, 3);
  if (sim.similarStudents.length > 0) {
    console.log(`\n  ${colors.bold}COLLABORATIVE PEER RECOMMENDATIONS (AI MATCHED):${colors.reset}`);
    sim.similarStudents.forEach((item, idx) => {
      console.log(`  #${idx + 1} ${item.student.name} (${item.student.rollNo} - ${item.student.department})`);
      console.log(`     Match: ${colors.green}${Math.round(item.similarityScore * 100)}%${colors.reset} | Shared Skills: ${item.sharedSkills.join(', ') || 'Domain synergy'}`);
    });
  }

  console.log(`\n${colors.cyan}========================================================================${colors.reset}\n`);
}

function runSimilarity(idOrRoll) {
  console.log(`\n${colors.bold}Finding Similar Students for:${colors.reset} "${colors.yellow}${idOrRoll}${colors.reset}"`);
  const res = studentService.findSimilar(idOrRoll, 5);

  if (!res.targetStudent) {
    console.log(`${colors.red}Student record not found for "${idOrRoll}".${colors.reset}`);
    return;
  }

  console.log(`Target: ${colors.bold}${res.targetStudent.name}${colors.reset} (${res.targetStudent.rollNo} - ${res.targetStudent.department})`);
  console.log(`${colors.dim}Calculation Time: ${res.executionTimeMs} ms | Vectors Compared: ${res.totalCompared}${colors.reset}\n`);

  res.similarStudents.forEach((item, i) => {
    const s = item.student;
    console.log(`  ${colors.green}#${i + 1}${colors.reset} ${colors.bold}${s.name} (${s.rollNo})${colors.reset} - ${s.department}`);
    console.log(`     Composite Similarity: ${colors.magenta}${Math.round(item.similarityScore * 100)}%${colors.reset} (Cosine: ${(item.cosineScore * 100).toFixed(0)}%, Jaccard: ${(item.jaccardScore * 100).toFixed(0)}%)`);
    console.log(`     Shared Skills: ${colors.cyan}${item.sharedSkills.join(', ') || 'Domain affinity'}${colors.reset}`);
  });
}

function runBenchmark(query) {
  console.log(`\n${colors.bold}Running Algorithmic Benchmark for keyword:${colors.reset} "${colors.yellow}${query}${colors.reset}"`);
  const res = studentService.benchmark(query);

  console.log(`
+----------------------------+-----------------------+-----------------------+
| Metric                     | 1. Linear Brute Force | 2. Inverted Index     |
+----------------------------+-----------------------+-----------------------+
| Time Complexity            | O(N x M)              | O(1) amortized        |
| Execution Time             | ${String(res.linearScan.timeMicroseconds + ' us').padEnd(21)} | ${String(res.invertedIndex.timeMicroseconds + ' us').padEnd(21)} |
| Comparisons / Lookups      | ${String(res.linearScan.comparisons + ' comparisons').padEnd(21)} | ${String(res.invertedIndex.comparisons + ' hash lookup').padEnd(21)} |
| Matches Found              | ${String(res.linearScan.matchesCount + ' records').padEnd(21)} | ${String(res.invertedIndex.matchesCount + ' records').padEnd(21)} |
+----------------------------+-----------------------+-----------------------+
`);
  console.log(`${colors.bold}${colors.green}Performance Advantage:${colors.reset} Inverted Index is ${colors.bold}${colors.magenta}${res.speedupMultiplier}x Faster${colors.reset} with zero table scans!`);
}

function listAllStudents() {
  const students = studentService.getAllStudents();
  console.log(`\n${colors.bold}Total Records in Database:${colors.reset} ${students.length}\n`);

  students.slice(0, 15).forEach((s, i) => {
    console.log(`${String(i + 1).padStart(2)}. [${s.rollNo}] ${s.name.padEnd(20)} | ${s.department.padEnd(35)} | CGPA: ${s.cgpa.toFixed(2)} | Att: ${s.attendance}%`);
  });

  if (students.length > 15) {
    console.log(`\n${colors.dim}...and ${students.length - 15} more records. Use search to filter.${colors.reset}`);
  }
}

function showSystemStats() {
  const stats = studentService.getDashboardStats();
  console.log(`\n${colors.bold}APEX UNIVERSITY SYSTEM TELEMETRY${colors.reset}`);
  console.log(`  Total Enrolled Students:  ${colors.cyan}${stats.totalStudents}${colors.reset}`);
  console.log(`  Average Student CGPA:     ${colors.green}${stats.averageCgpa}${colors.reset} / 10.0`);
  console.log(`  Average Attendance Rate:  ${colors.cyan}${stats.averageAttendance}%${colors.reset}`);
  console.log(`  Total Projects Built:     ${colors.magenta}${stats.totalProjects}${colors.reset}`);
  console.log(`  Trie Indexed Words:       ${colors.yellow}${stats.dsaStats.trieWords}${colors.reset}`);
  console.log(`  Inverted Index Postings:  ${colors.yellow}${stats.dsaStats.indexedTerms}${colors.reset}`);
  console.log(`  Unique Search Tokens:     ${colors.yellow}${stats.dsaStats.uniqueTokens}${colors.reset}`);

  console.log(`\n${colors.bold}Department Breakdown:${colors.reset}`);
  Object.entries(stats.departments).forEach(([dept, count]) => {
    console.log(`  - ${dept.padEnd(38)}: ${count} students`);
  });

  console.log(`\n${colors.bold}Top 5 In-Demand Skills:${colors.reset}`);
  stats.topSkills.slice(0, 5).forEach(sk => {
    console.log(`  - ${sk.name.padEnd(20)}: ${sk.count} students`);
  });
}
