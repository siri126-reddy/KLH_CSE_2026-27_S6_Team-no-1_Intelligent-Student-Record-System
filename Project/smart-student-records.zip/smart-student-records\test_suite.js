/**
 * Automated Verification Test Suite
 * Validates CRUD operations and all 6 core DSA algorithms
 */

const studentService = require('./src/services/studentService');
const assert = require('assert');

console.log('--- STARTING VERIFICATION TEST SUITE ---');

let passedTests = 0;
let totalTests = 0;

function runTest(testName, fn) {
  totalTests++;
  try {
    fn();
    console.log(`[PASS] ${testName}`);
    passedTests++;
  } catch (err) {
    console.error(`[FAIL] ${testName}:`, err.message);
  }
}

// 1. Test Dataset Initialization
runTest('Verify Dataset & Index Initialization', () => {
  const students = studentService.getAllStudents();
  assert(students.length >= 20, `Expected at least 20 students, got ${students.length}`);
  const stats = studentService.getDashboardStats();
  assert(stats.dsaStats.trieWords > 0, 'Trie should have indexed words');
  assert(stats.dsaStats.indexedTerms > 0, 'Inverted Index should have indexed terms');
});

// 2. Test Trie Autocomplete (Prefix Lookup)
runTest('Trie Autocomplete (Prefix: "Rup")', () => {
  const res = studentService.autocomplete('Rup');
  assert(res.suggestions.length > 0, 'Trie should return suggestions for "Rup"');
  const hasRupesh = res.suggestions.some(s => s.match.toLowerCase().includes('rupesh'));
  assert(hasRupesh, 'Should find "Rupesh" in Trie suggestions');
  console.log(`       Found ${res.suggestions.length} suggestions in ${res.executionTimeMs} ms`);
});

// 3. Test Inverted Index + Smart Relevance Ranking
runTest('Smart Search with Ranking (Query: "Machine Learning")', () => {
  const res = studentService.smartSearch('Machine Learning');
  assert(res.results.length > 0, 'Should find matches for Machine Learning');
  assert(res.results[0].score > 0, 'Top result should have a positive relevance score');
  assert(Array.isArray(res.results[0].breakdown), 'Result should have explainable score breakdown');
  console.log(`       Top match: ${res.results[0].student.name} with score ${res.results[0].score}%`);
});

// 4. Test Fuzzy Search (Levenshtein Distance Typo Tolerance)
runTest('Fuzzy Search with Typo ("Mchene" -> "Machine")', () => {
  const res = studentService.fuzzySearch('Mchene', 2);
  assert(res.results.length > 0, 'Should find fuzzy matches for typo "Mchene"');
  assert(res.bestMatrixSample !== null, 'Should compute and return Levenshtein DP matrix');
  console.log(`       Fuzzy matched: "${res.results[0].matchedTerm}" with edit distance ${res.results[0].editDistance}`);
});

// 5. Test Knuth-Morris-Pratt (KMP) Pattern Search
runTest('KMP Pattern Search ("neural")', () => {
  const res = studentService.kmpSearch('neural');
  assert(Array.isArray(res.lps), 'Should return LPS array');
  assert(res.lps.length === 'neural'.length, 'LPS length must match pattern length');
  assert(res.totalComparisons > 0, 'Should record character comparisons');
  console.log(`       KMP pattern "neural" LPS: [${res.lps.join(', ')}], Comparisons: ${res.totalComparisons}`);
});

// 6. Test Jaccard & Cosine Similarity Engine
runTest('Similarity Recommendation for STU-1001 (Rupesh Naidu)', () => {
  const res = studentService.findSimilar('STU-1001', 3);
  assert(res.similarStudents.length > 0, 'Should return similar students');
  const topPeer = res.similarStudents[0];
  assert(topPeer.similarityScore > 0, 'Top peer should have positive similarity score');
  assert(topPeer.sharedSkills.length >= 0, 'Should list shared skills');
  console.log(`       Top similar peer: ${topPeer.student.name} (${Math.round(topPeer.similarityScore * 100)}% match)`);
});

// 7. Test Algorithmic Benchmark (Linear Scan vs. Inverted Index)
runTest('Benchmark: Linear Scan vs. Inverted Index ("Python")', () => {
  const res = studentService.benchmark('Python');
  assert(res.linearScan.comparisons > res.invertedIndex.comparisons, 'Linear scan should perform more comparisons');
  assert(res.postingDetails !== null, 'Should return posting details');
  console.log(`       Linear: ${res.linearScan.timeMicroseconds} \u03bcs (${res.linearScan.comparisons} comparisons)`);
  console.log(`       Index:  ${res.invertedIndex.timeMicroseconds} \u03bcs (${res.invertedIndex.comparisons} comparisons)`);
  console.log(`       Speedup: ${res.speedupMultiplier}x`);
});

// 8. Test CRUD Operations Lifecycle
runTest('CRUD Lifecycle (Create -> Read -> Update -> Delete)', () => {
  // CREATE
  const created = studentService.createStudent({
    rollNo: '24TEST01',
    name: 'Test Student Alpha',
    department: 'Computer Science & Engineering',
    year: 1,
    semester: 1,
    cgpa: 9.8,
    attendance: 99,
    skills: ['Quantum Computing', 'Qiskit'],
    projectTitle: 'Quantum Simulator'
  });
  assert(created.id, 'Created student must have an ID');

  // Verify Trie updated
  const trieCheck = studentService.autocomplete('Quantum');
  assert(trieCheck.suggestions.length > 0, 'Trie must immediately index new student skill');

  // UPDATE
  const updated = studentService.updateStudent(created.id, {
    cgpa: 9.95,
    name: 'Test Student Alpha Updated'
  });
  assert(updated.cgpa === 9.95, 'CGPA must be updated');
  assert(updated.name === 'Test Student Alpha Updated', 'Name must be updated');

  // DELETE
  const deleted = studentService.deleteStudent(created.id);
  assert(deleted, 'Student must be deleted successfully');
  const afterDelete = studentService.getStudentById(created.id);
  assert(!afterDelete, 'Student must no longer exist after deletion');
});

// 9. Test Portal Authentication & Admin-Created Student Dossier
runTest('Portal Authentication & Admin Data Retrieval', () => {
  // Admin Login
  const adminAuth = studentService.authenticate('admin', 'admin', 'admin123');
  assert(adminAuth.success, 'Admin authentication must succeed');
  assert(adminAuth.role === 'admin', 'Role must be admin');

  // Student Login (21CS101)
  const studentAuth = studentService.authenticate('student', '21CS101', 'student123');
  assert(studentAuth.success, 'Student authentication must succeed');
  assert(studentAuth.role === 'student', 'Role must be student');
  assert(studentAuth.student.name === 'Rupesh Naidu', 'Name must match');
  assert(studentAuth.student.projects.length >= 1, 'Admin-created projects must be present');
  assert(studentAuth.student.skills.length >= 1, 'Admin-created skills must be present');
  console.log(`       Verified portal dossier for ${studentAuth.student.name} (${studentAuth.student.rollNo})`);
});

console.log(`\n--- TEST SUMMARY: ${passedTests}/${totalTests} TESTS PASSED ---`);
if (passedTests === totalTests) {
  console.log('ALL DSA & CRUD TESTS PASSED SUCCESSFULLY! ✅');
} else {
  process.exit(1);
}
