/**
 * Frontend Application Controller
 * Apex University - Smart Student Record Management & DSA Search System
 * Supports Role-Based Login Gateway, Dedicated Student Portal, and Admin Control Suite
 */

// Application State
const state = {
  auth: {
    isAuthenticated: false,
    role: null, // 'admin' | 'student'
    user: null,
    student: null
  },
  students: [],
  currentSearchResults: [],
  currentMode: 'ranked', // 'ranked' | 'fuzzy' | 'kmp'
  currentView: 'grid',   // 'grid' | 'table'
  lastTelemetry: null,
  activeFilters: {
    department: 'All',
    year: 'All',
    minCgpa: 0,
    minAttendance: 0
  },
  charts: {
    dept: null,
    skills: null
  }
};

// DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  initAuthSession();
  initEventListeners();
  loadStats();
  initLabSelectors();
  if (window.lucide) window.lucide.createIcons();
});

// --------------------------------------------------------------------------
// 1. AUTHENTICATION & PORTAL SESSION MANAGEMENT
// --------------------------------------------------------------------------

function initAuthSession() {
  const savedSession = localStorage.getItem('apex_user_session');
  if (savedSession) {
    try {
      const parsed = JSON.parse(savedSession);
      if (parsed && parsed.isAuthenticated) {
        state.auth = parsed;
        applyPortalView();
        return;
      }
    } catch (e) {
      console.warn('Corrupt session, resetting:', e);
      localStorage.removeItem('apex_user_session');
    }
  }

  // Default: Show Login Gateway
  showLoginGateway();
}

function setSession(sessionData) {
  state.auth = {
    isAuthenticated: true,
    role: sessionData.role,
    user: sessionData.user || null,
    student: sessionData.student || null
  };
  localStorage.setItem('apex_user_session', JSON.stringify(state.auth));
  applyPortalView();
}

function clearSession() {
  state.auth = {
    isAuthenticated: false,
    role: null,
    user: null,
    student: null
  };
  localStorage.removeItem('apex_user_session');
  showLoginGateway();
  showToast('You have signed out successfully.', 'info');
}

function showLoginGateway() {
  document.getElementById('loginGateway').classList.remove('hidden');
  document.getElementById('studentPortal').classList.add('hidden');
  document.getElementById('adminPortal').classList.add('hidden');

  // Header adjustments
  document.getElementById('portalBadge').textContent = 'Portal Gateway';
  document.getElementById('userChip').classList.add('hidden');
  document.getElementById('adminHeaderActions').classList.add('hidden');
  document.getElementById('btnLogout').classList.add('hidden');
  document.getElementById('btnNavToLogin').classList.add('hidden');

  if (window.lucide) window.lucide.createIcons();
}

function applyPortalView() {
  const { isAuthenticated, role, user, student } = state.auth;
  if (!isAuthenticated) {
    showLoginGateway();
    return;
  }

  const loginGateway = document.getElementById('loginGateway');
  const studentPortal = document.getElementById('studentPortal');
  const adminPortal = document.getElementById('adminPortal');
  const userChip = document.getElementById('userChip');
  const userAvatar = document.getElementById('userAvatar');
  const userName = document.getElementById('userName');
  const userRole = document.getElementById('userRole');
  const adminActions = document.getElementById('adminHeaderActions');
  const btnLogout = document.getElementById('btnLogout');
  const portalBadge = document.getElementById('portalBadge');

  loginGateway.classList.add('hidden');
  btnLogout.classList.remove('hidden');
  userChip.classList.remove('hidden');
  userChip.classList.add('flex');

  if (role === 'admin') {
    // Show Admin Portal
    studentPortal.classList.add('hidden');
    adminPortal.classList.remove('hidden');
    adminPortal.classList.add('flex');
    adminActions.classList.remove('hidden');
    adminActions.classList.add('flex');

    portalBadge.textContent = 'Admin Management Suite';
    userAvatar.textContent = 'AD';
    userAvatar.className = 'w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center font-bold text-[11px]';
    userName.textContent = (user && user.name) || 'Administrator';
    userRole.textContent = 'Campus Admin';

    // Refresh admin data
    executeSearch();
    loadStats();
  } else if (role === 'student') {
    // Show Student Portal
    adminPortal.classList.add('hidden');
    adminActions.classList.add('hidden');
    studentPortal.classList.remove('hidden');

    portalBadge.textContent = 'Student Portal';
    const initials = student ? student.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : 'ST';
    userAvatar.textContent = initials;
    userAvatar.className = 'w-6 h-6 rounded-full bg-brand-600 text-white flex items-center justify-center font-bold text-[11px]';
    userName.textContent = (student && student.name) || 'Student';
    userRole.textContent = (student && student.rollNo) || 'Student';

    // Populate Student's verified record
    renderStudentPortalData(student);
  }

  if (window.lucide) window.lucide.createIcons();
}

// --------------------------------------------------------------------------
// 2. STUDENT PORTAL DATA POPULATION
// --------------------------------------------------------------------------

async function renderStudentPortalData(student) {
  if (!student) return;

  // Re-fetch latest record from server to ensure admin updates are live
  let s = student;
  try {
    const res = await fetch(`/api/students/${student.id}`);
    const json = await res.json();
    if (json.success && json.data) {
      s = json.data;
      state.auth.student = s;
      localStorage.setItem('apex_user_session', JSON.stringify(state.auth));
    }
  } catch (err) {
    console.warn('Could not refresh student record from server:', err);
  }

  // Hero section
  const initials = s.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  document.getElementById('spHeroAvatar').textContent = initials;
  document.getElementById('spHeroName').textContent = s.name;
  document.getElementById('spHeroDept').textContent = s.department;
  document.getElementById('spHeroRoll').textContent = s.rollNo;
  document.getElementById('spHeroYearSem').textContent = `Academic Year ${s.year} • Semester ${s.semester}`;
  document.getElementById('spHeroId').textContent = `Record ID: ${s.id}`;
  document.getElementById('spHeroCgpa').textContent = s.cgpa ? s.cgpa.toFixed(2) : '-';
  document.getElementById('spHeroAtt').textContent = `${s.attendance || 0}%`;

  // Left card details
  document.getElementById('spInfoRoll').textContent = s.rollNo;
  document.getElementById('spInfoDept').textContent = s.department;
  document.getElementById('spInfoYear').textContent = `Year ${s.year}`;
  document.getElementById('spInfoSem').textContent = `Semester ${s.semester}`;
  document.getElementById('spInfoDbId').textContent = s.id;
  document.getElementById('spInfoEmail').textContent = s.email;
  document.getElementById('spInfoPhone').textContent = s.phone;

  // Skills
  const skillsContainer = document.getElementById('spSkillsCloud');
  const skillsCount = document.getElementById('spSkillsCount');
  skillsCount.textContent = `${(s.skills || []).length} registered skills`;

  skillsContainer.innerHTML = (s.skills || []).map(sk => `
    <span class="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700/80 font-medium text-xs text-brand-300 shadow-sm">
      ${sk}
    </span>
  `).join('');

  // 1. Hackathons & Competitive Innovations
  const hackContainer = document.getElementById('spHackathonsList');
  if (hackContainer) {
    if (s.hackathons && s.hackathons.length > 0) {
      hackContainer.innerHTML = s.hackathons.map((h, idx) => {
        const isObj = typeof h === 'object' && h !== null;
        const name = isObj ? h.name : h;
        const award = isObj && h.award ? h.award : (isObj && h.standing ? h.standing : 'Participant 🏅');
        const role = isObj && h.role ? h.role : 'Team Member';
        const project = isObj && h.project ? h.project : null;
        const year = isObj && h.year ? h.year : '';

        return `
          <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-2 hover:border-amber-500/40 transition">
            <div class="flex items-start sm:items-center justify-between gap-2">
              <div class="flex items-center gap-2.5">
                <span class="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center text-xs shrink-0 font-bold">
                  <i data-lucide="trophy" class="w-4 h-4 text-amber-400"></i>
                </span>
                <div>
                  <h4 class="font-bold text-white text-sm leading-tight">${name}</h4>
                  <div class="text-[11px] text-slate-400 mt-0.5">${role}${year ? ` &bull; ${year}` : ''}</div>
                </div>
              </div>
              <span class="text-[10px] font-mono-code px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 font-bold shrink-0">
                ${award}
              </span>
            </div>
            ${project ? `
              <div class="mt-2 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/80 text-xs">
                <span class="text-slate-400 text-[10px] uppercase font-bold tracking-wider block">Project Built:</span>
                <span class="text-slate-200 font-medium">${project}</span>
              </div>
            ` : ''}
          </div>
        `;
      }).join('');
    } else {
      hackContainer.innerHTML = `<p class="text-xs text-slate-500 italic p-3 bg-slate-900/40 rounded-xl border border-slate-800/60">No hackathon participation recorded yet.</p>`;
    }
  }

  // 2. Professional Industry Certifications
  const certContainer = document.getElementById('spCertificationsList');
  if (certContainer) {
    if (s.certifications && s.certifications.length > 0) {
      certContainer.innerHTML = s.certifications.map(c => {
        const isObj = typeof c === 'object' && c !== null;
        const name = isObj ? (c.name || c.title) : c;
        const issuer = isObj && c.issuer ? c.issuer : 'Accredited Authority';
        const credentialId = isObj && c.credentialId ? c.credentialId : 'VERIFIED-ID';
        const isVerified = isObj ? (c.verified !== false) : true;
        const date = isObj && c.date ? c.date : '';

        return `
          <div class="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 hover:border-emerald-500/40 transition flex flex-col justify-between space-y-2">
            <div>
              <div class="flex items-start justify-between gap-2 mb-1.5">
                <span class="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-xs shrink-0">
                  <i data-lucide="badge-check" class="w-4 h-4 text-emerald-400"></i>
                </span>
                ${isVerified ? `
                  <span class="text-[10px] font-medium px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                    <i data-lucide="shield-check" class="w-3 h-3"></i> Verified
                  </span>
                ` : ''}
              </div>
              <h4 class="font-bold text-slate-100 text-xs leading-snug">${name}</h4>
              <p class="text-[11px] text-slate-400 mt-1">${issuer}${date ? ` &bull; ${date}` : ''}</p>
            </div>
            <div class="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
              <span class="text-slate-500 font-mono-code">${credentialId}</span>
              <span class="text-emerald-400 font-semibold">Active Credential</span>
            </div>
          </div>
        `;
      }).join('');
    } else {
      certContainer.innerHTML = `<p class="col-span-2 text-xs text-slate-500 italic p-3 bg-slate-900/40 rounded-xl border border-slate-800/60">No certifications recorded yet.</p>`;
    }
  }

  // 3. Industry Internships & Technical Experience
  const internContainer = document.getElementById('spInternshipsList');
  if (internContainer) {
    if (s.internships && s.internships.length > 0) {
      internContainer.innerHTML = s.internships.map(i => {
        const isObj = typeof i === 'object' && i !== null;
        const role = isObj ? i.role : i;
        const company = isObj && i.company ? i.company : 'Industry Partner';
        const duration = isObj && i.duration ? i.duration : 'Technical Internship';
        const description = isObj && i.description ? i.description : '';

        return `
          <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-2 hover:border-cyan-500/40 transition">
            <div class="flex items-start sm:items-center justify-between gap-2">
              <div class="flex items-center gap-2.5">
                <span class="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center text-xs shrink-0">
                  <i data-lucide="briefcase" class="w-4 h-4 text-cyan-400"></i>
                </span>
                <div>
                  <h4 class="font-bold text-white text-sm leading-tight">${role}</h4>
                  <div class="text-[11px] text-cyan-400 font-medium mt-0.5">${company}</div>
                </div>
              </div>
              <span class="text-[10px] font-mono-code px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 shrink-0">
                ${duration}
              </span>
            </div>
            ${description ? `<p class="text-xs text-slate-300 leading-relaxed mt-2">${description}</p>` : ''}
          </div>
        `;
      }).join('');
    } else {
      internContainer.innerHTML = `<p class="text-xs text-slate-500 italic p-3 bg-slate-900/40 rounded-xl border border-slate-800/60">No internships recorded yet.</p>`;
    }
  }

  // Fetch Recommended Peers for this student using Cosine & Jaccard similarity
  fetchStudentPeerRecommendations(s.id);

  if (window.lucide) window.lucide.createIcons();
}

async function fetchStudentPeerRecommendations(studentId) {
  const container = document.getElementById('spPeerRecommendations');
  try {
    const res = await fetch(`/api/dsa/similarity/${studentId}?topK=4`);
    const json = await res.json();
    if (!json.success || !json.data) {
      container.innerHTML = `<p class="text-xs text-slate-500">Unable to calculate peer recommendations.</p>`;
      return;
    }

    const { similarStudents, executionTimeMs } = json.data;
    if (similarStudents.length === 0) {
      container.innerHTML = `<p class="text-xs text-slate-500">No similar peers found.</p>`;
      return;
    }

    container.innerHTML = similarStudents.map((item, idx) => {
      const p = item.student;
      const pct = Math.round(item.similarityScore * 100);
      const shared = item.sharedSkills && item.sharedSkills.length > 0
        ? item.sharedSkills.join(', ')
        : 'Interdisciplinary domain synergy';

      return `
        <div class="bg-slate-900/70 p-3 rounded-xl border border-slate-800 hover:border-emerald-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition">
          <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center font-bold text-xs shrink-0">
              #${idx + 1}
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="font-bold text-white text-xs sm:text-sm">${p.name}</span>
                <span class="font-mono-code text-[11px] text-brand-400 font-medium">${p.rollNo}</span>
              </div>
              <p class="text-[11px] text-slate-400 mt-0.5">${p.department} (Year ${p.year})</p>
              <div class="text-[11px] text-slate-300 mt-1">
                <span class="text-slate-400">Overlapping Skills:</span>
                <span class="text-emerald-300 font-medium">${shared}</span>
              </div>
            </div>
          </div>

          <div class="text-right shrink-0">
            <span class="text-base font-black text-emerald-400 font-mono-code">${pct}%</span>
            <span class="text-[10px] text-slate-400 block">Match Score</span>
          </div>
        </div>
      `;
    }).join('');

    if (window.lucide) window.lucide.createIcons();
  } catch (err) {
    container.innerHTML = `<p class="text-xs text-rose-400">Error loading peer recommendations.</p>`;
  }
}

// --------------------------------------------------------------------------
// 3. LOGIN GATEWAY FORM & EVENT LISTENERS
// --------------------------------------------------------------------------

function initEventListeners() {
  // Portal Role Tabs inside Login Gateway
  const tabStudent = document.getElementById('tabRoleStudent');
  const tabAdmin = document.getElementById('tabRoleAdmin');
  const loginRole = document.getElementById('loginRole');
  const lblIdentifier = document.getElementById('lblIdentifier');
  const loginIdentifier = document.getElementById('loginIdentifier');
  const pwdHint = document.getElementById('pwdHint');
  const btnLoginText = document.getElementById('btnLoginText');
  const demoStudentButtons = document.getElementById('demoStudentButtons');
  const demoAdminButtons = document.getElementById('demoAdminButtons');

  tabStudent.addEventListener('click', () => {
    loginRole.value = 'student';
    tabStudent.className = 'py-2.5 rounded-lg transition flex items-center justify-center gap-1.5 bg-brand-600 text-white shadow';
    tabAdmin.className = 'py-2.5 rounded-lg transition flex items-center justify-center gap-1.5 text-slate-400 hover:text-slate-200';
    lblIdentifier.textContent = 'Roll Number or Student Email';
    loginIdentifier.placeholder = 'e.g. 21CS101 or rupesh.naidu@campus.edu';
    pwdHint.textContent = 'Default: student123';
    btnLoginText.textContent = 'Sign In to Student Portal';
    demoStudentButtons.classList.remove('hidden');
    demoAdminButtons.classList.add('hidden');
  });

  tabAdmin.addEventListener('click', () => {
    loginRole.value = 'admin';
    tabAdmin.className = 'py-2.5 rounded-lg transition flex items-center justify-center gap-1.5 bg-purple-600 text-white shadow';
    tabStudent.className = 'py-2.5 rounded-lg transition flex items-center justify-center gap-1.5 text-slate-400 hover:text-slate-200';
    lblIdentifier.textContent = 'Administrator Username or Email';
    loginIdentifier.placeholder = 'admin or admin@campus.edu';
    pwdHint.textContent = 'Default: admin123';
    btnLoginText.textContent = 'Sign In to Admin Portal';
    demoStudentButtons.classList.add('hidden');
    demoAdminButtons.classList.remove('hidden');
  });

  // Password Visibility Toggle
  const btnTogglePwd = document.getElementById('btnTogglePwd');
  const loginPassword = document.getElementById('loginPassword');
  btnTogglePwd.addEventListener('click', () => {
    const isPwd = loginPassword.type === 'password';
    loginPassword.type = isPwd ? 'text' : 'password';
    btnTogglePwd.innerHTML = `<i data-lucide="${isPwd ? 'eye-off' : 'eye'}" class="w-4 h-4"></i>`;
    if (window.lucide) window.lucide.createIcons();
  });

  // Login Form Submission
  document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const role = loginRole.value;
    const identifier = loginIdentifier.value.trim();
    const password = loginPassword.value.trim();

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role, identifier, password })
      });

      const json = await res.json();
      if (!json.success) {
        showToast(json.error || 'Authentication failed', 'error');
        return;
      }

      showToast(`Welcome back, ${role === 'admin' ? json.user.name : json.student.name}!`, 'success');
      setSession(json);
    } catch (err) {
      showToast('Login server error: ' + err.message, 'error');
    }
  });

  // Logout Button
  document.getElementById('btnLogout').addEventListener('click', clearSession);

  // Admin Navigation Tabs
  document.querySelectorAll('.nav-tab').forEach(tabBtn => {
    tabBtn.addEventListener('click', () => {
      const targetTab = tabBtn.dataset.tab;
      switchTab(targetTab);
    });
  });

  // Main Search Input with Debounced Autocomplete
  const searchInput = document.getElementById('mainSearchInput');
  const btnClearSearch = document.getElementById('btnClearSearch');

  let debounceTimer = null;
  searchInput.addEventListener('input', (e) => {
    const val = e.target.value.trim();
    btnClearSearch.classList.toggle('hidden', val.length === 0);

    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      if (val.length >= 1) {
        fetchTrieAutocomplete(val);
      } else {
        hideTrieDropdown();
      }
      executeSearch();
    }, 180);
  });

  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') hideTrieDropdown();
  });

  btnClearSearch.addEventListener('click', () => {
    searchInput.value = '';
    btnClearSearch.classList.add('hidden');
    hideTrieDropdown();
    executeSearch();
  });

  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    const container = document.getElementById('trieDropdown');
    const input = document.getElementById('mainSearchInput');
    if (container && !container.contains(e.target) && e.target !== input) {
      hideTrieDropdown();
    }

    const exportBtn = document.getElementById('btnExportMenu');
    const exportDropdown = document.getElementById('exportDropdown');
    if (exportBtn && exportDropdown && !exportBtn.contains(e.target) && !exportDropdown.contains(e.target)) {
      exportDropdown.classList.add('hidden');
    }
  });

  // Search Engine Mode Switcher
  document.querySelectorAll('.search-mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.search-mode-btn').forEach(b => {
        b.classList.remove('active', 'bg-brand-600', 'text-white');
        b.classList.add('text-slate-400');
      });
      btn.classList.add('active', 'bg-brand-600', 'text-white');
      btn.classList.remove('text-slate-400');

      state.currentMode = btn.dataset.mode;
      document.getElementById('fuzzyOptions').classList.toggle('hidden', state.currentMode !== 'fuzzy');
      executeSearch();
    });
  });

  document.getElementById('fuzzyThresholdSelect').addEventListener('change', () => {
    executeSearch();
  });

  // View Switcher (Grid vs Table)
  document.getElementById('btnViewGrid').addEventListener('click', () => setView('grid'));
  document.getElementById('btnViewTable').addEventListener('click', () => setView('table'));

  // Filter Drawer Toggle
  const btnToggleFilters = document.getElementById('btnToggleFilters');
  const filterDrawer = document.getElementById('filterDrawer');
  btnToggleFilters.addEventListener('click', () => {
    filterDrawer.classList.toggle('hidden');
  });

  // Filters Input Changes
  document.getElementById('filterDept').addEventListener('change', (e) => {
    state.activeFilters.department = e.target.value;
    updateFilterBadge();
    executeSearch();
  });

  document.getElementById('filterYear').addEventListener('change', (e) => {
    state.activeFilters.year = e.target.value;
    updateFilterBadge();
    executeSearch();
  });

  const minCgpaInput = document.getElementById('filterMinCgpa');
  minCgpaInput.addEventListener('input', (e) => {
    state.activeFilters.minCgpa = parseFloat(e.target.value);
    document.getElementById('minCgpaDisplay').textContent = e.target.value;
    updateFilterBadge();
    executeSearch();
  });

  const minAttInput = document.getElementById('filterMinAtt');
  minAttInput.addEventListener('input', (e) => {
    state.activeFilters.minAttendance = parseInt(e.target.value, 10);
    document.getElementById('minAttDisplay').textContent = `${e.target.value}%`;
    updateFilterBadge();
    executeSearch();
  });

  // Export Dropdown
  const btnExportMenu = document.getElementById('btnExportMenu');
  const exportDropdown = document.getElementById('exportDropdown');
  btnExportMenu.addEventListener('click', (e) => {
    e.stopPropagation();
    exportDropdown.classList.toggle('hidden');
  });

  document.getElementById('btnExportCSV').addEventListener('click', exportCSV);
  document.getElementById('btnExportJSON').addEventListener('click', exportJSON);

  // Add Student Modal Open/Close
  document.getElementById('btnOpenAddModal').addEventListener('click', () => openStudentModal());
  document.getElementById('btnCloseModal').addEventListener('click', () => closeStudentModal());
  document.getElementById('btnCancelModal').addEventListener('click', () => closeStudentModal());
  document.getElementById('studentForm').addEventListener('submit', handleStudentFormSubmit);

  // Details Modal Close
  document.getElementById('btnCloseDetailsModal').addEventListener('click', () => closeDetailsModal());
  document.getElementById('btnCloseDetailsBottom').addEventListener('click', () => closeDetailsModal());

  // Similarity Modal Close
  document.getElementById('btnCloseSimilarityModal').addEventListener('click', () => {
    document.getElementById('similarityModal').classList.add('hidden');
  });

  // Inspector Modal
  document.getElementById('btnInspectAlgorithm').addEventListener('click', openInspectorModal);
  document.getElementById('btnCloseInspectorModal').addEventListener('click', () => {
    document.getElementById('inspectorModal').classList.add('hidden');
  });

  // LAB & BENCHMARK EVENT LISTENERS
  document.getElementById('btnLabTrieSearch').addEventListener('click', runLabTrie);
  document.getElementById('labTrieInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') runLabTrie();
  });

  document.getElementById('btnLabCalcDp').addEventListener('click', runLabFuzzyMatrix);
  document.getElementById('btnLabRunKmp').addEventListener('click', runLabKmp);
  document.getElementById('btnLabRunSimilarity').addEventListener('click', runLabSimilarity);

  document.getElementById('btnRunBenchmark').addEventListener('click', runBenchmark);
  document.getElementById('benchmarkQueryInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') runBenchmark();
  });
}

// --------------------------------------------------------------------------
// 4. QUICK 1-CLICK DEMO LOGIN HELPER
// --------------------------------------------------------------------------

window.quickLogin = async function(role, identifier, password) {
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role, identifier, password })
    });

    const json = await res.json();
    if (!json.success) {
      showToast(json.error || 'Quick login failed', 'error');
      return;
    }

    showToast(`Signed in as ${role === 'admin' ? json.user.name : json.student.name}`, 'success');
    setSession(json);
  } catch (err) {
    showToast('Login error: ' + err.message, 'error');
  }
};

// --------------------------------------------------------------------------
// 5. TAB SWITCHING (ADMIN PORTAL)
// --------------------------------------------------------------------------

function switchTab(tabId) {
  document.querySelectorAll('.nav-tab').forEach(tab => {
    const isCurrent = tab.dataset.tab === tabId;
    tab.classList.toggle('active', isCurrent);
    tab.classList.toggle('bg-slate-800', isCurrent);
    tab.classList.toggle('text-white', isCurrent);
    tab.classList.toggle('text-slate-400', !isCurrent);
  });

  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.toggle('hidden', content.id !== tabId);
    content.classList.toggle('block', content.id === tabId);
  });

  if (tabId === 'tab-analytics') {
    renderCharts();
  } else if (tabId === 'tab-benchmark') {
    runBenchmark();
  } else if (tabId === 'tab-dsa-lab') {
    runLabTrie();
    runLabFuzzyMatrix();
  }

  if (window.lucide) window.lucide.createIcons();
}

function updateFilterBadge() {
  const hasFilters = state.activeFilters.department !== 'All' ||
                     state.activeFilters.year !== 'All' ||
                     state.activeFilters.minCgpa > 0 ||
                     state.activeFilters.minAttendance > 0;
  document.getElementById('filterActiveBadge').classList.toggle('hidden', !hasFilters);
}

function setView(viewMode) {
  state.currentView = viewMode;
  const btnGrid = document.getElementById('btnViewGrid');
  const btnTable = document.getElementById('btnViewTable');

  if (viewMode === 'grid') {
    btnGrid.classList.add('text-brand-400');
    btnGrid.classList.remove('text-slate-400');
    btnTable.classList.add('text-slate-400');
    btnTable.classList.remove('text-brand-400');
    document.getElementById('studentsGrid').classList.remove('hidden');
    document.getElementById('studentsTableWrapper').classList.add('hidden');
  } else {
    btnTable.classList.add('text-brand-400');
    btnTable.classList.remove('text-slate-400');
    btnGrid.classList.add('text-slate-400');
    btnGrid.classList.remove('text-brand-400');
    document.getElementById('studentsGrid').classList.add('hidden');
    document.getElementById('studentsTableWrapper').classList.remove('hidden');
  }
}

// --------------------------------------------------------------------------
// 6. STATS & OVERVIEW API
// --------------------------------------------------------------------------

async function loadStats() {
  try {
    const res = await fetch('/api/stats');
    const json = await res.json();
    if (json.success && json.data) {
      const data = json.data;
      const totalEl = document.getElementById('statTotalStudents');
      const cgpaEl = document.getElementById('statAvgCgpa');
      const attEl = document.getElementById('statAvgAttendance');
      const projEl = document.getElementById('statTotalProjects');
      const trieEl = document.getElementById('statTrieWords');
      const termsEl = document.getElementById('statIndexedTerms');

      if (totalEl) totalEl.textContent = data.totalStudents;
      if (cgpaEl) cgpaEl.textContent = data.averageCgpa.toFixed(2);
      if (attEl) attEl.textContent = `${data.averageAttendance}%`;
      if (projEl) projEl.textContent = data.totalProjects;

      if (data.dsaStats) {
        if (trieEl) trieEl.textContent = data.dsaStats.trieWords;
        if (termsEl) termsEl.textContent = data.dsaStats.indexedTerms;
      }

      state.statsData = data;
    }
  } catch (err) {
    console.error('Error loading stats:', err);
  }
}

// --------------------------------------------------------------------------
// 7. SEARCH & ALGORITHM EXECUTION
// --------------------------------------------------------------------------

async function executeSearch() {
  const searchInput = document.getElementById('mainSearchInput');
  if (!searchInput) return;
  const query = searchInput.value.trim();
  const mode = state.currentMode;

  try {
    let url = '';
    const params = new URLSearchParams();

    if (state.activeFilters.department !== 'All') {
      params.append('department', state.activeFilters.department);
    }
    if (state.activeFilters.year !== 'All') {
      params.append('year', state.activeFilters.year);
    }
    if (state.activeFilters.minCgpa > 0) {
      params.append('minCgpa', state.activeFilters.minCgpa);
    }
    if (state.activeFilters.minAttendance > 0) {
      params.append('minAttendance', state.activeFilters.minAttendance);
    }

    if (mode === 'ranked') {
      params.append('q', query);
      url = `/api/search?${params.toString()}`;
    } else if (mode === 'fuzzy') {
      const threshold = document.getElementById('fuzzyThresholdSelect').value;
      params.append('q', query);
      params.append('threshold', threshold);
      url = `/api/dsa/fuzzy?${params.toString()}`;
    } else if (mode === 'kmp') {
      params.append('pattern', query);
      url = `/api/dsa/kmp?${params.toString()}`;
    }

    const res = await fetch(url);
    const json = await res.json();

    if (!json.success) throw new Error(json.error || 'Search error');

    handleSearchResults(json.data, mode, query);

  } catch (err) {
    console.error('Search failed:', err);
  }
}

function handleSearchResults(data, mode, query) {
  state.lastTelemetry = { mode, query, data };
  let items = [];
  let execTime = 0;
  let algorithmLabel = '';

  if (mode === 'ranked') {
    items = data.results || [];
    execTime = data.executionTimeMs || 0.1;
    algorithmLabel = data.algorithm || 'Inverted Index + Multi-Factor Ranker';
  } else if (mode === 'fuzzy') {
    items = (data.results || []).map(r => ({
      student: r.student,
      score: Math.round(r.fuzzyScore * 100),
      breakdown: [
        { reason: `Matched "${r.matchedTerm}" (${r.field})`, points: Math.round(r.fuzzyScore * 100) },
        { reason: `Levenshtein Edit Distance: ${r.editDistance}`, points: 0 }
      ],
      fuzzyDetails: r
    }));
    execTime = data.executionTimeMs || 0.1;
    algorithmLabel = `Levenshtein DP (Max Distance: ${data.threshold})`;
  } else if (mode === 'kmp') {
    items = (data.results || []).map(r => ({
      student: r.student,
      score: 95,
      breakdown: [
        { reason: `Found ${r.matchCount} exact pattern match(es)`, points: 95 }
      ],
      kmpDetails: r
    }));
    execTime = data.executionTimeMs || 0.1;
    algorithmLabel = `Knuth-Morris-Pratt Pattern Matcher (Zero Backtrack)`;
  }

  // Filter client-side if fuzzy or KMP modes are active
  if (mode !== 'ranked') {
    if (state.activeFilters.department !== 'All') {
      items = items.filter(i => i.student.department.toLowerCase() === state.activeFilters.department.toLowerCase());
    }
    if (state.activeFilters.minCgpa > 0) {
      items = items.filter(i => i.student.cgpa >= state.activeFilters.minCgpa);
    }
    if (state.activeFilters.minAttendance > 0) {
      items = items.filter(i => i.student.attendance >= state.activeFilters.minAttendance);
    }
  }

  state.currentSearchResults = items;

  // Update telemetry banner
  const resultCountEl = document.getElementById('telemetryResultCount');
  const timeEl = document.getElementById('telemetryTime');
  const algoEl = document.getElementById('telemetryAlgorithm');

  if (resultCountEl) resultCountEl.textContent = items.length;
  if (timeEl) timeEl.textContent = `${execTime} ms`;
  if (algoEl) algoEl.textContent = algorithmLabel;

  renderStudentResults(items, mode, query);
}

// --------------------------------------------------------------------------
// 8. RENDERING ADMIN RESULTS (CARDS & TABLE)
// --------------------------------------------------------------------------

function renderStudentResults(items, mode, query) {
  const gridContainer = document.getElementById('studentsGrid');
  const tableBody = document.getElementById('studentsTableBody');
  const emptyState = document.getElementById('emptyState');

  if (!gridContainer || !tableBody) return;

  if (items.length === 0) {
    gridContainer.innerHTML = '';
    tableBody.innerHTML = '';
    if (emptyState) emptyState.classList.remove('hidden');
    return;
  }

  if (emptyState) emptyState.classList.add('hidden');

  // Render Grid Cards
  gridContainer.innerHTML = items.map(item => {
    const s = item.student;
    const initials = s.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

    const cgpaColor = s.cgpa >= 9.0 ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
                    : s.cgpa >= 8.0 ? 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30'
                    : 'text-amber-400 bg-amber-500/10 border-amber-500/30';

    const skillsHtml = (s.skills || []).slice(0, 4).map(sk => `
      <span class="skill-tag cursor-pointer px-2 py-0.5 rounded text-[11px] bg-slate-800 text-slate-300 hover:bg-brand-600 hover:text-white transition" onclick="triggerSkillSearch('${sk}')">
        ${sk}
      </span>
    `).join('');

    const scoreBadge = item.score ? `
      <div class="px-2 py-0.5 rounded-full text-[11px] font-mono-code font-bold ${item.score >= 80 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-brand-500/20 text-brand-300 border border-brand-500/30'} flex items-center gap-1" title="${(item.breakdown || []).map(b => b.reason).join('\n')}">
        <i data-lucide="award" class="w-3 h-3"></i>
        <span>${item.score}% Match</span>
      </div>
    ` : '';

    const projCount = (s.projects || []).length;
    const firstProj = (s.projects && s.projects[0]) ? s.projects[0].title : 'None';

    return `
      <div class="student-card glass-panel rounded-2xl p-5 border border-slate-800 flex flex-col justify-between relative overflow-hidden">
        <div>
          <div class="flex items-center justify-between gap-2 mb-3">
            <span class="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700/80 font-mono-code text-xs font-bold text-brand-400">
              ${s.rollNo}
            </span>
            ${scoreBadge}
          </div>

          <div class="flex items-start gap-3 mb-4">
            <div class="w-11 h-11 rounded-xl bg-gradient-to-tr from-brand-600/40 to-indigo-500/40 border border-brand-500/30 flex items-center justify-center font-bold text-sm text-brand-300 shrink-0">
              ${initials}
            </div>
            <div>
              <h4 class="font-bold text-white text-base leading-tight hover:text-brand-300 cursor-pointer transition" onclick="viewStudentDetails('${s.id}')">
                ${s.name}
              </h4>
              <p class="text-xs text-slate-400 mt-0.5">${s.department}</p>
              <div class="text-[11px] text-slate-500 mt-0.5">Year ${s.year} &bull; Semester ${s.semester}</div>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-2 mb-4">
            <div class="bg-slate-900/60 rounded-xl p-2.5 border border-slate-800/80">
              <div class="flex justify-between items-center text-xs mb-1">
                <span class="text-slate-400">CGPA</span>
                <span class="font-bold font-mono-code ${cgpaColor} px-1.5 py-0.2 rounded border">${s.cgpa.toFixed(2)}</span>
              </div>
              <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div class="bg-emerald-500 h-full rounded-full" style="width: ${(s.cgpa / 10) * 100}%"></div>
              </div>
            </div>

            <div class="bg-slate-900/60 rounded-xl p-2.5 border border-slate-800/80">
              <div class="flex justify-between items-center text-xs mb-1">
                <span class="text-slate-400">Attendance</span>
                <span class="font-bold font-mono-code text-cyan-400">${s.attendance}%</span>
              </div>
              <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div class="bg-cyan-500 h-full rounded-full" style="width: ${s.attendance}%"></div>
              </div>
            </div>
          </div>

          <div class="mb-4">
            <div class="text-[11px] uppercase font-semibold text-slate-400 mb-1.5 flex items-center justify-between">
              <span>Skills</span>
              <span class="text-slate-500">${(s.skills || []).length} total</span>
            </div>
            <div class="flex flex-wrap gap-1.5">
              ${skillsHtml}
            </div>
          </div>

          <div class="bg-slate-900/40 rounded-xl p-2.5 border border-slate-800/60 text-xs text-slate-300 mb-4">
            <div class="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
              <i data-lucide="folder-git-2" class="w-3.5 h-3.5 text-purple-400"></i>
              <span>Featured Project (${projCount} total)</span>
            </div>
            <p class="font-medium text-slate-200 line-clamp-1">${firstProj}</p>
          </div>
        </div>

        <div class="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
          <button onclick="findSimilarStudents('${s.id}')" class="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg bg-emerald-950/40 border border-emerald-800/50 hover:bg-emerald-900/50 text-emerald-300 text-xs font-medium transition">
            <i data-lucide="users" class="w-3.5 h-3.5"></i>
            <span>Similar</span>
          </button>

          <button onclick="viewStudentDetails('${s.id}')" class="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition">
            <i data-lucide="eye" class="w-3.5 h-3.5"></i>
            <span>Details</span>
          </button>

          <button onclick="openStudentModal('${s.id}')" class="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition" title="Edit Student">
            <i data-lucide="edit-3" class="w-3.5 h-3.5"></i>
          </button>

          <button onclick="deleteStudentRecord('${s.id}')" class="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/60 text-slate-400 hover:text-rose-300 transition" title="Delete Student">
            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
          </button>
        </div>
      </div>
    `;
  }).join('');

  // Render Table View
  tableBody.innerHTML = items.map(item => {
    const s = item.student;
    return `
      <tr class="hover:bg-slate-900/50 transition">
        <td class="px-4 py-3">
          <div class="font-bold text-white hover:text-brand-300 cursor-pointer" onclick="viewStudentDetails('${s.id}')">${s.name}</div>
          <div class="text-xs font-mono-code text-brand-400">${s.rollNo} &bull; ${s.email}</div>
        </td>
        <td class="px-4 py-3 text-xs">
          <div class="text-slate-200">${s.department}</div>
          <div class="text-slate-500">Year ${s.year}, Sem ${s.semester}</div>
        </td>
        <td class="px-4 py-3">
          <span class="font-mono-code font-bold text-xs ${s.cgpa >= 9.0 ? 'text-emerald-400' : s.cgpa >= 8.0 ? 'text-cyan-400' : 'text-amber-400'}">
            ${s.cgpa.toFixed(2)}
          </span>
        </td>
        <td class="px-4 py-3 font-mono-code text-xs text-cyan-400">
          ${s.attendance}%
        </td>
        <td class="px-4 py-3">
          <div class="flex flex-wrap gap-1 max-w-xs">
            ${(s.skills || []).slice(0, 3).map(sk => `<span class="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300">${sk}</span>`).join('')}
          </div>
        </td>
        <td class="px-4 py-3 text-right">
          <div class="flex items-center justify-end gap-1.5">
            <button onclick="findSimilarStudents('${s.id}')" class="p-1 rounded bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900/50" title="Find Similar">
              <i data-lucide="users" class="w-3.5 h-3.5"></i>
            </button>
            <button onclick="viewStudentDetails('${s.id}')" class="p-1 rounded bg-slate-800 text-slate-300 hover:text-white" title="View Details">
              <i data-lucide="eye" class="w-3.5 h-3.5"></i>
            </button>
            <button onclick="openStudentModal('${s.id}')" class="p-1 rounded bg-slate-800 text-slate-300 hover:text-white" title="Edit">
              <i data-lucide="edit-3" class="w-3.5 h-3.5"></i>
            </button>
            <button onclick="deleteStudentRecord('${s.id}')" class="p-1 rounded bg-slate-800 text-slate-400 hover:text-rose-400" title="Delete">
              <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  if (window.lucide) window.lucide.createIcons();
}

function triggerSkillSearch(skillName) {
  const searchInput = document.getElementById('mainSearchInput');
  if (!searchInput) return;
  searchInput.value = skillName;
  document.getElementById('btnClearSearch').classList.remove('hidden');
  hideTrieDropdown();
  executeSearch();
}

// --------------------------------------------------------------------------
// 9. TRIE AUTOCOMPLETE DROPDOWN
// --------------------------------------------------------------------------

async function fetchTrieAutocomplete(query) {
  try {
    const res = await fetch(`/api/autocomplete?q=${encodeURIComponent(query)}&limit=8`);
    const json = await res.json();
    if (!json.success || !json.data) return;

    const { suggestions, executionTimeMs } = json.data;
    const dropdown = document.getElementById('trieDropdown');
    const list = document.getElementById('trieSuggestionsList');
    const timeBadge = document.getElementById('trieTimeBadge');

    if (!dropdown || !list) return;

    if (suggestions.length === 0) {
      hideTrieDropdown();
      return;
    }

    if (timeBadge) timeBadge.textContent = `${executionTimeMs} ms`;

    list.innerHTML = suggestions.map(item => {
      const iconMap = {
        'Name': 'user',
        'Roll No': 'hash',
        'Skill': 'code-2',
        'Department': 'building-2'
      };
      const icon = iconMap[item.type] || 'search';

      return `
        <div class="autocomplete-item px-3 py-2 rounded-lg hover:bg-brand-600/20 hover:text-white cursor-pointer transition flex items-center justify-between text-xs" onclick="selectTrieSuggestion('${item.match.replace(/'/g, "\\'")}')">
          <div class="flex items-center gap-2">
            <i data-lucide="${icon}" class="w-3.5 h-3.5 text-brand-400"></i>
            <span class="font-medium text-slate-200">${item.match}</span>
          </div>
          <span class="text-[10px] font-mono-code px-1.5 py-0.5 rounded bg-slate-800/80 text-slate-400">${item.type}</span>
        </div>
      `;
    }).join('');

    dropdown.classList.remove('hidden');
    if (window.lucide) window.lucide.createIcons();
  } catch (err) {
    console.error('Trie autocomplete failed:', err);
  }
}

function selectTrieSuggestion(text) {
  const input = document.getElementById('mainSearchInput');
  if (!input) return;
  input.value = text;
  document.getElementById('btnClearSearch').classList.remove('hidden');
  hideTrieDropdown();
  executeSearch();
}

function hideTrieDropdown() {
  const dd = document.getElementById('trieDropdown');
  if (dd) dd.classList.add('hidden');
}

// --------------------------------------------------------------------------
// 10. STUDENT CRUD OPERATIONS
// --------------------------------------------------------------------------

async function openStudentModal(studentId = null) {
  const modal = document.getElementById('studentModal');
  const title = document.getElementById('modalTitle');
  const form = document.getElementById('studentForm');
  form.reset();

  if (studentId) {
    title.textContent = 'Edit Student Record';
    document.getElementById('formStudentId').value = studentId;

    try {
      const res = await fetch(`/api/students/${studentId}`);
      const json = await res.json();
      if (json.success && json.data) {
        const s = json.data;
        document.getElementById('formRollNo').value = s.rollNo;
        document.getElementById('formName').value = s.name;
        document.getElementById('formDepartment').value = s.department;
        document.getElementById('formYear').value = s.year;
        document.getElementById('formSemester').value = s.semester;
        document.getElementById('formCgpa').value = s.cgpa;
        document.getElementById('formAttendance').value = s.attendance;
        document.getElementById('formEmail').value = s.email;
        document.getElementById('formPhone').value = s.phone;
        document.getElementById('formSkills').value = (s.skills || []).join(', ');
        document.getElementById('formCertifications').value = (s.certifications || []).map(c => typeof c === 'string' ? c : c.name || c.title || '').join(', ');
        document.getElementById('formHackathons').value = (s.hackathons || []).map(h => typeof h === 'string' ? h : `${h.name}${h.award ? ' - ' + h.award : ''}`).join(', ');
        document.getElementById('formInternships').value = (s.internships || []).map(i => typeof i === 'string' ? i : `${i.role || ''} at ${i.company || ''}`).join(', ');
        if (s.projects && s.projects[0]) {
          document.getElementById('formProjTitle').value = s.projects[0].title;
          document.getElementById('formProjDesc').value = s.projects[0].description || '';
        }
        document.getElementById('formAchievements').value = (s.achievements || []).join(', ');
      }
    } catch (err) {
      showToast('Could not load student details', 'error');
    }
  } else {
    title.textContent = 'Add New Student Record';
    document.getElementById('formStudentId').value = '';
    document.getElementById('formRollNo').value = `24CS${Math.floor(100 + Math.random() * 900)}`;
    document.getElementById('formCertifications').value = '';
    document.getElementById('formHackathons').value = '';
    document.getElementById('formInternships').value = '';
  }

  modal.classList.remove('hidden');
}

function closeStudentModal() {
  document.getElementById('studentModal').classList.add('hidden');
}

async function handleStudentFormSubmit(e) {
  e.preventDefault();
  const studentId = document.getElementById('formStudentId').value;

  const payload = {
    rollNo: document.getElementById('formRollNo').value,
    name: document.getElementById('formName').value,
    department: document.getElementById('formDepartment').value,
    year: parseInt(document.getElementById('formYear').value, 10),
    semester: parseInt(document.getElementById('formSemester').value, 10),
    cgpa: parseFloat(document.getElementById('formCgpa').value),
    attendance: parseInt(document.getElementById('formAttendance').value, 10),
    email: document.getElementById('formEmail').value,
    phone: document.getElementById('formPhone').value,
    skills: document.getElementById('formSkills').value.split(',').map(s => s.trim()).filter(s => s.length > 0),
    certifications: document.getElementById('formCertifications').value.split(',').map(c => c.trim()).filter(c => c.length > 0),
    hackathons: document.getElementById('formHackathons').value.split(',').map(h => h.trim()).filter(h => h.length > 0),
    internships: document.getElementById('formInternships').value.split(',').map(i => i.trim()).filter(i => i.length > 0),
    projects: [
      {
        title: document.getElementById('formProjTitle').value || 'University Capstone',
        description: document.getElementById('formProjDesc').value || '',
        techStack: []
      }
    ],
    achievements: document.getElementById('formAchievements').value.split(',').map(a => a.trim()).filter(a => a.length > 0)
  };

  try {
    const url = studentId ? `/api/students/${studentId}` : '/api/students';
    const method = studentId ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Failed to save');

    showToast(studentId ? 'Record updated & indexes synced!' : 'Student created & indexed in Trie + Inverted Index!', 'success');
    closeStudentModal();
    loadStats();
    executeSearch();
    initLabSelectors();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteStudentRecord(studentId) {
  if (!confirm(`Are you sure you want to delete student ${studentId}? Indexes will automatically synchronize.`)) {
    return;
  }

  try {
    const res = await fetch(`/api/students/${studentId}`, { method: 'DELETE' });
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Delete failed');

    showToast(`Deleted record ${studentId}. Trie and Inverted Index resynced.`, 'success');
    loadStats();
    executeSearch();
    initLabSelectors();
  } catch (err) {
    showToast('Delete error: ' + err.message, 'error');
  }
}

// --------------------------------------------------------------------------
// 11. VIEW DETAILS & SIMILARITY RECOMMENDATIONS
// --------------------------------------------------------------------------

async function viewStudentDetails(studentId) {
  try {
    const res = await fetch(`/api/students/${studentId}`);
    const json = await res.json();
    if (!json.success || !json.data) return;

    const s = json.data;
    const modal = document.getElementById('detailsModal');

    document.getElementById('detailAvatar').textContent = s.name.split(' ').map(n => n[0]).join('').slice(0, 2);
    document.getElementById('detailName').textContent = s.name;
    document.getElementById('detailRollNo').textContent = s.rollNo;
    document.getElementById('detailDept').textContent = s.department;

    document.getElementById('btnDetailFindSimilar').onclick = () => {
      closeDetailsModal();
      findSimilarStudents(s.id);
    };

    const content = document.getElementById('detailContent');
    content.innerHTML = `
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
          <span class="text-slate-400 block mb-1">Academic Year</span>
          <span class="font-bold text-white text-sm">Year ${s.year} &bull; Sem ${s.semester}</span>
        </div>
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
          <span class="text-slate-400 block mb-1">CGPA (out of 10)</span>
          <span class="font-bold font-mono-code text-emerald-400 text-sm">${s.cgpa.toFixed(2)}</span>
        </div>
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
          <span class="text-slate-400 block mb-1">Attendance</span>
          <span class="font-bold font-mono-code text-cyan-400 text-sm">${s.attendance}%</span>
        </div>
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
          <span class="text-slate-400 block mb-1">Record ID</span>
          <span class="font-bold font-mono-code text-brand-400 text-sm">${s.id}</span>
        </div>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800 flex items-center gap-2">
          <i data-lucide="mail" class="w-4 h-4 text-brand-400"></i>
          <div>
            <div class="text-slate-400">Campus Email</div>
            <div class="font-mono-code text-slate-200">${s.email}</div>
          </div>
        </div>
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800 flex items-center gap-2">
          <i data-lucide="phone" class="w-4 h-4 text-emerald-400"></i>
          <div>
            <div class="text-slate-400">Contact Number</div>
            <div class="font-mono-code text-slate-200">${s.phone}</div>
          </div>
        </div>
      </div>

      <div>
        <h4 class="text-xs uppercase font-bold text-slate-400 mb-2 flex items-center gap-1.5">
          <i data-lucide="code" class="w-3.5 h-3.5 text-brand-400"></i>
          <span>Technical Skills Cloud</span>
        </h4>
        <div class="flex flex-wrap gap-1.5">
          ${(s.skills || []).map(sk => `
            <span class="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 font-medium text-xs text-brand-300">
              ${sk}
            </span>
          `).join('')}
        </div>
      </div>

      ${(s.hackathons && s.hackathons.length > 0) ? `
      <div>
        <h4 class="text-xs uppercase font-bold text-slate-400 mb-2 flex items-center gap-1.5">
          <i data-lucide="trophy" class="w-3.5 h-3.5 text-amber-400"></i>
          <span>Hackathons & Competitive Innovations</span>
        </h4>
        <div class="space-y-2">
          ${s.hackathons.map(h => {
            const isObj = typeof h === 'object' && h !== null;
            const name = isObj ? h.name : h;
            const award = isObj && h.award ? h.award : 'Participant 🏅';
            const role = isObj && h.role ? h.role : '';
            const project = isObj && h.project ? h.project : '';
            return `
              <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex items-start justify-between gap-2">
                <div>
                  <div class="font-bold text-white text-xs">${name}</div>
                  ${role ? `<div class="text-[11px] text-slate-400 mt-0.5">${role}</div>` : ''}
                  ${project ? `<div class="text-[11px] text-slate-300 mt-1">Project: ${project}</div>` : ''}
                </div>
                <span class="text-[10px] font-mono-code px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 font-bold shrink-0">
                  ${award}
                </span>
              </div>
            `;
          }).join('')}
        </div>
      </div>
      ` : ''}

      ${(s.certifications && s.certifications.length > 0) ? `
      <div>
        <h4 class="text-xs uppercase font-bold text-slate-400 mb-2 flex items-center gap-1.5">
          <i data-lucide="badge-check" class="w-3.5 h-3.5 text-emerald-400"></i>
          <span>Professional Industry Certifications</span>
        </h4>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
          ${s.certifications.map(c => {
            const isObj = typeof c === 'object' && c !== null;
            const name = isObj ? (c.name || c.title) : c;
            const issuer = isObj && c.issuer ? c.issuer : 'Accredited Authority';
            const credentialId = isObj && c.credentialId ? c.credentialId : '';
            return `
              <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex flex-col justify-between">
                <div>
                  <div class="font-bold text-white text-xs leading-snug">${name}</div>
                  <div class="text-[11px] text-slate-400 mt-0.5">${issuer}</div>
                </div>
                ${credentialId ? `<div class="text-[10px] text-slate-500 font-mono-code mt-2 pt-1 border-t border-slate-800">${credentialId}</div>` : ''}
              </div>
            `;
          }).join('')}
        </div>
      </div>
      ` : ''}

      ${(s.internships && s.internships.length > 0) ? `
      <div>
        <h4 class="text-xs uppercase font-bold text-slate-400 mb-2 flex items-center gap-1.5">
          <i data-lucide="briefcase" class="w-3.5 h-3.5 text-cyan-400"></i>
          <span>Industry Internships & Experience</span>
        </h4>
        <div class="space-y-2">
          ${s.internships.map(i => {
            const isObj = typeof i === 'object' && i !== null;
            const role = isObj ? i.role : i;
            const company = isObj && i.company ? i.company : 'Industry Partner';
            const duration = isObj && i.duration ? i.duration : '';
            const desc = isObj && i.description ? i.description : '';
            return `
              <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <div class="flex items-center justify-between text-xs">
                  <span class="font-bold text-white">${role}</span>
                  <span class="text-cyan-400 font-medium">${company}</span>
                </div>
                ${duration ? `<div class="text-[10px] font-mono-code text-slate-400 mt-0.5">${duration}</div>` : ''}
                ${desc ? `<p class="text-[11px] text-slate-300 mt-1">${desc}</p>` : ''}
              </div>
            `;
          }).join('')}
        </div>
      </div>
      ` : ''}

      ${(s.projects && s.projects.length > 0) ? `
      <div>
        <h4 class="text-xs uppercase font-bold text-slate-400 mb-2 flex items-center gap-1.5">
          <i data-lucide="folder-git-2" class="w-3.5 h-3.5 text-purple-400"></i>
          <span>Engineering Projects & Software</span>
        </h4>
        <div class="space-y-2">
          ${(s.projects || []).map(p => `
            <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
              <div class="font-bold text-white text-sm">${p.title}</div>
              <p class="text-xs text-slate-400 mt-1">${p.description || 'No description provided.'}</p>
              ${p.techStack && p.techStack.length > 0 ? `
                <div class="flex flex-wrap gap-1 mt-2">
                  ${p.techStack.map(t => `<span class="px-1.5 py-0.5 rounded text-[10px] bg-purple-950/60 text-purple-300 border border-purple-800/40">${t}</span>`).join('')}
                </div>
              ` : ''}
            </div>
          `).join('')}
        </div>
      </div>
      ` : ''}

      ${(s.achievements && s.achievements.length > 0) ? `
      <div>
        <h4 class="text-xs uppercase font-bold text-slate-400 mb-2 flex items-center gap-1.5">
          <i data-lucide="award" class="w-3.5 h-3.5 text-amber-400"></i>
          <span>Honors & Achievements</span>
        </h4>
        <ul class="space-y-1.5 text-xs text-slate-300">
          ${(s.achievements || []).map(ach => `
            <li class="flex items-center gap-2 bg-slate-900/40 p-2 rounded-lg border border-slate-800/60">
              <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-400 shrink-0"></i>
              <span>${ach}</span>
            </li>
          `).join('')}
        </ul>
      </div>
      ` : ''}
    `;

    modal.classList.remove('hidden');
    if (window.lucide) window.lucide.createIcons();
  } catch (err) {
    showToast('Failed to open student details', 'error');
  }
}

function closeDetailsModal() {
  document.getElementById('detailsModal').classList.add('hidden');
}

async function findSimilarStudents(studentId) {
  try {
    const res = await fetch(`/api/dsa/similarity/${studentId}?topK=5`);
    const json = await res.json();
    if (!json.success || !json.data) return;

    const { targetStudent, similarStudents, executionTimeMs } = json.data;
    const modal = document.getElementById('similarityModal');
    document.getElementById('similarityTargetName').textContent = `${targetStudent.name} (${targetStudent.rollNo} - ${targetStudent.department})`;

    const list = document.getElementById('similarityModalList');
    list.innerHTML = `
      <div class="text-xs text-slate-400 flex items-center justify-between pb-2 border-b border-slate-800">
        <span>Showing top 5 recommended peers based on Jaccard & Cosine Vector Analysis:</span>
        <span class="font-mono-code text-emerald-400">${executionTimeMs} ms</span>
      </div>
    ` + similarStudents.map((item, idx) => {
      const s = item.student;
      const pct = Math.round(item.similarityScore * 100);

      return `
        <div class="glass-panel p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-emerald-500/40 transition">
          <div class="flex items-start gap-3">
            <div class="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm shrink-0">
              #${idx + 1}
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="font-bold text-white text-sm">${s.name}</span>
                <span class="font-mono-code text-xs text-brand-400">${s.rollNo}</span>
                ${item.sameDepartment ? '<span class="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">Same Dept</span>' : ''}
              </div>
              <p class="text-xs text-slate-400 mt-0.5">${s.department}</p>
              <div class="mt-2 text-xs">
                <span class="text-slate-400">Overlapping Skills:</span>
                <span class="text-emerald-300 font-medium">${item.sharedSkills.length > 0 ? item.sharedSkills.join(', ') : 'Cross-domain match'}</span>
              </div>
            </div>
          </div>

          <div class="flex sm:flex-col items-end justify-between shrink-0">
            <div class="text-right">
              <span class="text-lg font-black text-emerald-400 font-mono-code">${pct}%</span>
              <span class="text-[11px] text-slate-400 block">Similarity</span>
            </div>
            <div class="text-[10px] font-mono-code text-slate-500 mt-1">
              Cosine: ${(item.cosineScore * 100).toFixed(0)}% | Jaccard: ${(item.jaccardScore * 100).toFixed(0)}%
            </div>
          </div>
        </div>
      `;
    }).join('');

    modal.classList.remove('hidden');
    if (window.lucide) window.lucide.createIcons();
  } catch (err) {
    showToast('Failed to find similar students', 'error');
  }
}

// --------------------------------------------------------------------------
// 12. ALGORITHM INSPECTOR MODAL
// --------------------------------------------------------------------------

function openInspectorModal() {
  const modal = document.getElementById('inspectorModal');
  const container = document.getElementById('inspectorModalContent');
  const telemetry = state.lastTelemetry;

  if (!telemetry) {
    container.innerHTML = `<p class="text-sm text-slate-400">No recent search telemetry available. Perform a search first.</p>`;
    modal.classList.remove('hidden');
    return;
  }

  const { mode, query, data } = telemetry;

  container.innerHTML = `
    <div class="p-4 rounded-xl bg-slate-900/80 border border-slate-800 grid grid-cols-3 gap-3 text-xs">
      <div>
        <span class="text-slate-400 block">Current Query:</span>
        <span class="font-mono-code text-white font-bold text-sm">"${query || '*'}"</span>
      </div>
      <div>
        <span class="text-slate-400 block">Active Algorithm:</span>
        <span class="font-semibold text-brand-400">${mode.toUpperCase()}</span>
      </div>
      <div>
        <span class="text-slate-400 block">Execution Latency:</span>
        <span class="font-mono-code text-emerald-400 font-bold">${data.executionTimeMs || 0.1} ms</span>
      </div>
    </div>

    ${mode === 'fuzzy' && data.bestMatrixSample ? `
      <div>
        <h4 class="text-xs uppercase font-bold text-amber-400 mb-2">Levenshtein Dynamic Programming Table Sample</h4>
        <p class="text-xs text-slate-400 mb-3">
          Comparing query token <strong>"${data.bestMatrixSample.str1}"</strong> with record match <strong>"${data.bestMatrixSample.str2}"</strong> (Distance: ${data.bestMatrixSample.distance}):
        </p>
        <div class="overflow-x-auto bg-slate-950 p-4 rounded-xl border border-slate-800">
          ${renderMatrixHtml(data.bestMatrixSample.str1, data.bestMatrixSample.str2, data.bestMatrixSample.matrix)}
        </div>
      </div>
    ` : ''}

    ${mode === 'kmp' && data.lps ? `
      <div>
        <h4 class="text-xs uppercase font-bold text-cyan-400 mb-2">KMP Longest Prefix Suffix (LPS) Preprocessing Table</h4>
        <div class="overflow-x-auto bg-slate-950 p-4 rounded-xl border border-slate-800">
          <table class="dp-table w-full text-center">
            <thead>
              <tr>
                <th>Index</th>
                ${data.pattern.split('').map((c, i) => `<th>${i}</th>`).join('')}
              </tr>
              <tr>
                <th>Pattern Char</th>
                ${data.pattern.split('').map(c => `<th class="text-amber-400">${c}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="font-bold text-cyan-400">LPS[i]</td>
                ${data.lps.map(v => `<td class="font-bold text-white">${v}</td>`).join('')}
              </tr>
            </tbody>
          </table>
        </div>
        <div class="mt-3 text-xs text-slate-400">
          Total pattern character comparisons during scan: <strong class="text-white">${data.totalComparisons}</strong>
        </div>
      </div>
    ` : ''}

    ${mode === 'ranked' ? `
      <div>
        <h4 class="text-xs uppercase font-bold text-brand-400 mb-2">Multi-Criteria Score Breakdown for Top Match</h4>
        ${data.results && data.results[0] ? `
          <div class="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div class="flex items-center justify-between mb-3">
              <span class="font-bold text-white text-sm">${data.results[0].student.name} (${data.results[0].student.rollNo})</span>
              <span class="font-mono-code text-emerald-400 font-bold">${data.results[0].score}% Total Score</span>
            </div>
            <div class="space-y-1.5 text-xs">
              ${(data.results[0].breakdown || []).map(b => `
                <div class="flex items-center justify-between py-1 border-b border-slate-900">
                  <span class="text-slate-300">&bull; ${b.reason}</span>
                  <span class="font-mono-code text-brand-300 font-semibold">+${b.points} pts</span>
                </div>
              `).join('')}
            </div>
          </div>
        ` : '<p class="text-xs text-slate-500">No records scored.</p>'}
      </div>
    ` : ''}
  `;

  modal.classList.remove('hidden');
}

function renderMatrixHtml(str1, str2, matrix) {
  if (!matrix || matrix.length === 0) return '';
  const rows = str1.length + 1;
  const cols = str2.length + 1;

  let html = `<table class="dp-table mx-auto"><thead><tr><th></th><th>&epsilon;</th>`;
  for (let j = 0; j < str2.length; j++) {
    html += `<th>${str2[j]}</th>`;
  }
  html += `</tr></thead><tbody>`;

  for (let i = 0; i < rows; i++) {
    const rowChar = i === 0 ? '&epsilon;' : str1[i - 1];
    html += `<tr><th>${rowChar}</th>`;
    for (let j = 0; j < cols; j++) {
      const isTarget = i === rows - 1 && j === cols - 1;
      html += `<td class="${isTarget ? 'active-cell' : ''}">${matrix[i][j]}</td>`;
    }
    html += `</tr>`;
  }

  html += `</tbody></table>`;
  return html;
}

// --------------------------------------------------------------------------
// 13. DSA LAB TAB CONTROLLERS
// --------------------------------------------------------------------------

async function initLabSelectors() {
  try {
    const res = await fetch('/api/students');
    const json = await res.json();
    if (json.success && json.data) {
      const select = document.getElementById('labSimilarityStudentSelect');
      if (select) {
        select.innerHTML = json.data.slice(0, 30).map(s => `
          <option value="${s.id}">${s.name} (${s.rollNo} - ${s.department})</option>
        `).join('');
      }
    }
  } catch (err) {
    console.error('Error populating similarity student select:', err);
  }
}

async function runLabTrie() {
  const input = document.getElementById('labTrieInput');
  if (!input) return;
  const prefix = input.value.trim() || 'Rup';
  const out = document.getElementById('labTrieResults');

  try {
    const res = await fetch(`/api/autocomplete?q=${encodeURIComponent(prefix)}&limit=15`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error);

    const { suggestions, executionTimeMs, totalWordsInTrie } = json.data;

    if (suggestions.length === 0) {
      out.innerHTML = `<div class="text-slate-500">No prefix match found for "${prefix}". Trie contains ${totalWordsInTrie} indexed nodes.</div>`;
      return;
    }

    out.innerHTML = `
      <div class="text-amber-400 mb-2 pb-2 border-b border-slate-800 flex justify-between">
        <span>Trie Prefix Traversal for: "${prefix}"</span>
        <span>Lookup Time: ${executionTimeMs} ms</span>
      </div>
      <div class="space-y-1">
        ${suggestions.map((s, i) => `
          <div class="flex items-center justify-between py-0.5">
            <span>[${i + 1}] <strong class="text-white">${s.match.slice(0, prefix.length)}</strong>${s.match.slice(prefix.length)}</span>
            <span class="text-slate-400 text-[10px]">[Type: ${s.type}]</span>
          </div>
        `).join('')}
      </div>
    `;
  } catch (err) {
    out.innerHTML = `<span class="text-rose-400">Error: ${err.message}</span>`;
  }
}

function runLabFuzzyMatrix() {
  const w1El = document.getElementById('labFuzzyWord1');
  const w2El = document.getElementById('labFuzzyWord2');
  if (!w1El || !w2El) return;

  const w1 = w1El.value.trim() || 'Rupes';
  const w2 = w2El.value.trim() || 'Rupesh';
  const container = document.getElementById('labDpMatrixContainer');

  const m = w1.length;
  const n = w2.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = w1[i - 1].toLowerCase() === w2[j - 1].toLowerCase() ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost
      );
    }
  }

  const distance = dp[m][n];
  const maxLen = Math.max(m, n);
  const similarity = Math.max(0, 1 - distance / maxLen);

  container.innerHTML = `
    <div class="flex justify-between items-center mb-3 pb-2 border-b border-slate-800 text-xs">
      <div>
        <span class="text-slate-400">Minimum Edit Distance:</span>
        <strong class="text-purple-300 font-mono-code ml-1 text-sm">${distance}</strong>
      </div>
      <div>
        <span class="text-slate-400">Typo Match Score:</span>
        <strong class="text-emerald-400 font-mono-code ml-1 text-sm">${(similarity * 100).toFixed(1)}%</strong>
      </div>
    </div>
    ${renderMatrixHtml(w1, w2, dp)}
  `;
}

async function runLabKmp() {
  const input = document.getElementById('labKmpPattern');
  if (!input) return;
  const pattern = input.value.trim() || 'neural';
  const out = document.getElementById('labKmpOutput');

  try {
    const res = await fetch(`/api/dsa/kmp?pattern=${encodeURIComponent(pattern)}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error);

    const { results, lps, totalComparisons, executionTimeMs } = json.data;

    out.innerHTML = `
      <div class="flex justify-between text-cyan-400 mb-2 pb-2 border-b border-slate-800">
        <span>KMP Search: "${pattern}"</span>
        <span>Comparisons: ${totalComparisons} | Time: ${executionTimeMs} ms</span>
      </div>

      <div class="mb-3">
        <span class="text-slate-400 text-[11px] block mb-1">Precomputed LPS Array:</span>
        <div class="inline-flex gap-1 text-[11px] font-mono-code bg-slate-900 p-1.5 rounded border border-slate-800">
          ${pattern.split('').map((ch, i) => `
            <div class="text-center px-1.5 py-0.5 bg-slate-800 rounded">
              <div class="text-amber-400">${ch}</div>
              <div class="text-white font-bold">${lps[i]}</div>
            </div>
          `).join('')}
        </div>
      </div>

      <div class="space-y-2 mt-2">
        <span class="text-slate-400 text-[11px] block">Matches across student records (${results.length} students):</span>
        ${results.slice(0, 5).map(r => `
          <div class="bg-slate-900/60 p-2 rounded border border-slate-800 text-xs">
            <div class="font-bold text-white">${r.student.name} (${r.student.rollNo}) - ${r.matchCount} occurrence(s)</div>
            ${(r.matchDetails || []).map(m => `
              <div class="text-[11px] text-slate-400 mt-0.5">
                <span class="text-cyan-400 font-semibold">${m.field}:</span>
                "${m.snippet.before}<span class="match-highlight">${m.snippet.matched}</span>${m.snippet.after}"
              </div>
            `).join('')}
          </div>
        `).join('')}
      </div>
    `;
  } catch (err) {
    out.innerHTML = `<span class="text-rose-400">Error: ${err.message}</span>`;
  }
}

async function runLabSimilarity() {
  const select = document.getElementById('labSimilarityStudentSelect');
  if (!select) return;
  const studentId = select.value;
  const out = document.getElementById('labSimilarityOutput');

  try {
    const res = await fetch(`/api/dsa/similarity/${studentId}?topK=5`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error);

    const { targetStudent, similarStudents, executionTimeMs } = json.data;

    out.innerHTML = `
      <div class="flex justify-between text-emerald-400 mb-2 pb-2 border-b border-slate-800 text-xs">
        <span>Target: ${targetStudent.name} (${targetStudent.department})</span>
        <span>${executionTimeMs} ms</span>
      </div>
      <div class="space-y-2">
        ${similarStudents.map((s, idx) => `
          <div class="bg-slate-900/60 p-2.5 rounded-lg border border-slate-800 flex justify-between items-center text-xs">
            <div>
              <div class="font-bold text-white">#${idx + 1} ${s.student.name} (${s.student.rollNo})</div>
              <div class="text-[11px] text-slate-400">${s.student.department} &bull; Overlap: <span class="text-emerald-300 font-medium">${s.sharedSkills.join(', ') || 'N/A'}</span></div>
            </div>
            <div class="text-right">
              <span class="font-mono-code font-bold text-emerald-400">${(s.similarityScore * 100).toFixed(1)}%</span>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  } catch (err) {
    out.innerHTML = `<span class="text-rose-400">Error: ${err.message}</span>`;
  }
}

// --------------------------------------------------------------------------
// 14. BENCHMARK CONTROLLER (LINEAR SCAN VS INVERTED INDEX)
// --------------------------------------------------------------------------

async function runBenchmark() {
  const input = document.getElementById('benchmarkQueryInput');
  if (!input) return;
  const query = input.value.trim() || 'Python';

  try {
    const res = await fetch(`/api/dsa/benchmark?q=${encodeURIComponent(query)}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error);

    const d = json.data;

    document.getElementById('benchLinearTime').textContent = `${d.linearScan.timeMicroseconds} \u03bcs`;
    document.getElementById('benchLinearComps').textContent = `${d.linearScan.comparisons} comparisons`;
    document.getElementById('benchLinearMatches').textContent = `${d.linearScan.matchesCount} records`;

    document.getElementById('benchIndexTime').textContent = `${d.invertedIndex.timeMicroseconds} \u03bcs`;
    document.getElementById('benchIndexComps').textContent = `${d.invertedIndex.comparisons} hash lookup`;
    document.getElementById('benchIndexMatches').textContent = `${d.invertedIndex.matchesCount} records`;

    document.getElementById('benchSpeedup').textContent = `${d.speedupMultiplier}x`;

    const postingBox = document.getElementById('benchPostingListDisplay');
    if (d.postingDetails) {
      postingBox.innerHTML = `
        <div class="mb-2">
          Token: <strong class="text-emerald-400 font-bold">"${d.postingDetails.token}"</strong> |
          Document Count: <strong class="text-white">${d.postingDetails.documentCount}</strong>
        </div>
        <div class="space-y-1">
          ${d.postingDetails.postings.map(p => `
            <div class="bg-slate-900/80 p-2 rounded border border-slate-800 flex items-center justify-between">
              <span class="text-brand-300 font-bold">${p.studentId}</span>
              <span class="text-slate-400 text-[11px]">Frequency: ${p.count} in [${p.fields.join(', ')}]</span>
            </div>
          `).join('')}
        </div>
      `;
    } else {
      postingBox.innerHTML = `Token <strong>"${query}"</strong> is not present in the inverted index posting lists.`;
    }
  } catch (err) {
    showToast('Benchmark failed: ' + err.message, 'error');
  }
}

// --------------------------------------------------------------------------
// 15. CHARTS (DEPARTMENT & SKILLS)
// --------------------------------------------------------------------------

function renderCharts() {
  if (!state.statsData) return;
  const { departments, topSkills } = state.statsData;

  const deptCtx = document.getElementById('deptChart');
  if (deptCtx) {
    if (state.charts.dept) state.charts.dept.destroy();

    const labels = Object.keys(departments);
    const data = Object.values(departments);

    state.charts.dept = new Chart(deptCtx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: [
            '#6366f1', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'
          ],
          borderWidth: 2,
          borderColor: '#0f172a'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { color: '#94a3b8', font: { size: 11 } }
          }
        }
      }
    });
  }

  const skillsCtx = document.getElementById('skillsChart');
  if (skillsCtx) {
    if (state.charts.skills) state.charts.skills.destroy();

    const labels = topSkills.map(s => s.name);
    const data = topSkills.map(s => s.count);

    state.charts.skills = new Chart(skillsCtx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Students Possessing Skill',
          data,
          backgroundColor: '#4f46e5',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { ticks: { color: '#94a3b8', font: { size: 10 } }, grid: { display: false } },
          y: { ticks: { color: '#94a3b8', stepSize: 1 }, grid: { color: '#1e293b' } }
        },
        plugins: {
          legend: { display: false }
        }
      }
    });
  }
}

// --------------------------------------------------------------------------
// 16. DATA EXPORT (CSV & JSON)
// --------------------------------------------------------------------------

function exportCSV() {
  const items = state.currentSearchResults.length > 0 ? state.currentSearchResults : state.students;
  if (!items || items.length === 0) {
    showToast('No records to export', 'error');
    return;
  }

  const headers = ['ID', 'RollNo', 'Name', 'Department', 'Year', 'Semester', 'CGPA', 'Attendance', 'Email', 'Phone', 'Skills'];
  const rows = items.map(item => {
    const s = item.student || item;
    return [
      `"${s.id}"`,
      `"${s.rollNo}"`,
      `"${s.name}"`,
      `"${s.department}"`,
      s.year,
      s.semester,
      s.cgpa,
      s.attendance,
      `"${s.email}"`,
      `"${s.phone}"`,
      `"${(s.skills || []).join(';')}"`
    ].join(',');
  });

  const csvContent = [headers.join(','), ...rows].join('\n');
  downloadBlob(csvContent, 'student_records.csv', 'text/csv');
  showToast('Exported student records to CSV', 'success');
}

function exportJSON() {
  const items = state.currentSearchResults.length > 0 ? state.currentSearchResults : state.students;
  const cleanData = items.map(i => i.student || i);
  downloadBlob(JSON.stringify(cleanData, null, 2), 'student_records.json', 'application/json');
  showToast('Exported student records to JSON', 'success');
}

function downloadBlob(content, filename, contentType) {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// --------------------------------------------------------------------------
// 17. TOAST NOTIFICATIONS
// --------------------------------------------------------------------------

function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const toast = document.createElement('div');
  const isError = type === 'error';
  const isSuccess = type === 'success';

  toast.className = `px-4 py-2.5 rounded-xl border text-xs font-medium flex items-center gap-2 shadow-2xl animate-fade-in pointer-events-auto ${
    isError ? 'bg-rose-950/90 border-rose-800 text-rose-200' :
    isSuccess ? 'bg-emerald-950/90 border-emerald-800 text-emerald-200' :
    'bg-slate-900/90 border-slate-700 text-slate-200'
  }`;

  const icon = isError ? 'alert-circle' : isSuccess ? 'check-circle' : 'info';
  toast.innerHTML = `<i data-lucide="${icon}" class="w-4 h-4 shrink-0"></i><span>${message}</span>`;
  container.appendChild(toast);
  if (window.lucide) window.lucide.createIcons();

  setTimeout(() => {
    toast.classList.add('opacity-0', 'transition-opacity', 'duration-300');
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
