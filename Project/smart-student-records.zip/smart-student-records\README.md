# Smart Student Record Management & DSA Search Portal

A comprehensive, full-stack university student management and algorithmic search system built entirely with **Node.js**.

The project directly addresses the limitations of traditional database searching by implementing core **Data Structures and Algorithms (DSA)** in pure vanilla JavaScript without relying on third-party search engines:
- **Trie (Prefix Tree)** for real-time auto-complete
- **Inverted Indexing** for fast tokenized search ($O(1)$ amortized lookup vs $O(N)$ linear scans)
- **Knuth-Morris-Pratt (KMP)** for substring pattern matching with LPS arrays
- **Levenshtein Distance** for typo-tolerant fuzzy search
- **Jaccard & Cosine Similarity** for student profile recommendation
- **Multi-Factor Relevance Ranking** for intelligent result ordering

---

## 🚀 How to Run Everything Through Node.js

All components can be launched directly using standard Node.js and NPM commands:

### 1. Launch the Web Portal Dashboard & REST API
```bash
node server.js
# Or with npm:
npm start
```
- Starts the Express server on **`http://localhost:3000`**
- Serves the modern interactive Tailwind CSS frontend dashboard
- Exposes all REST API endpoints for search, autocomplete, and CRUD

### 2. Run the Interactive Terminal CLI
```bash
node cli.js
# Or with npm:
npm run cli
```
Launches an interactive command-line interface with a formatted menu for:
- Smart ranked searching
- Trie prefix autocomplete
- Levenshtein fuzzy search
- KMP pattern searching
- Student similarity recommendations
- Live benchmarking

You can also run one-shot CLI queries:
```bash
node cli.js search "Machine Learning"
node cli.js autocomplete "Rup"
node cli.js fuzzy "Mchene"
node cli.js kmp "neural"
node cli.js benchmark "Python"
node cli.js similar STU-1001
```

### 3. Run the Algorithmic Benchmark Suite
```bash
node benchmark_cli.js
# Or with npm:
npm run benchmark
```
Executes a side-by-side benchmark comparing **Brute-Force Linear Scanning** against **Inverted Indexing** across multiple queries. Measures:
- Execution time in microseconds ($\mu s$)
- Total character/record comparison counts
- Exact speedup multiplier (typically **10x - 50x faster**)

### 4. Run the Automated Verification Test Suite
```bash
node test_suite.js
# Or with npm:
npm test
```
Runs 8 automated unit tests verifying that all 6 DSA algorithms and the complete CRUD lifecycle function correctly.

### 5. Re-generate / Seed the Dataset
```bash
node src/data/seed.js
# Or with npm:
npm run seed
```
Generates 100 realistic student records across 6 engineering departments (CSE, AI & DS, IT, ECE, EEE, MECH) and rebuilds the indexes.

---

## 📂 Project Architecture

```
smart-student-records/
├── package.json                 # Project scripts and dependencies
├── server.js                    # Express REST API & static file server
├── cli.js                       # Interactive terminal REPL & command runner
├── benchmark_cli.js             # Command-line algorithmic benchmark suite
├── test_suite.js                # 8-point automated test suite
├── README.md                    # Project documentation
├── src/
│   ├── data/
│   │   ├── seed.js              # 100-student dataset generator
│   │   └── students.json        # Persistent JSON database
│   ├── dsa/
│   │   ├── trie.js              # Trie (Prefix Tree) for autocomplete
│   │   ├── invertedIndex.js     # Inverted Index with posting lists
│   │   ├── kmp.js               # Knuth-Morris-Pratt pattern search & LPS array
│   │   ├── fuzzy.js             # Levenshtein distance 2D dynamic programming
│   │   ├── similarity.js        # Jaccard set overlap & Cosine vector similarity
│   │   └── ranker.js            # Multi-criteria relevance scoring engine
│   └── services/
│       └── studentService.js    # CRUD coordinator & automatic index synchronizer
└── public/
    ├── index.html               # Responsive frontend portal dashboard
    ├── app.js                   # Client-side state, DOM rendering & events
    └── style.css                # Custom glassmorphism styling & animations
```

---

## 🧠 DSA Complexity Analysis

| Algorithm / Feature | Data Structure | Time Complexity | Space Complexity | Solved Problem |
|---|---|---|---|---|
| **Autocomplete** | Trie (Prefix Tree) | $O(L)$ where $L$ is query length | $O(W \cdot \Sigma)$ | Instant suggestions while typing |
| **Indexed Search** | Inverted Index | $O(1)$ amortized token lookup | $O(T)$ tokens & postings | Replaces slow $O(N)$ linear scans |
| **Pattern Search** | Knuth-Morris-Pratt | $O(N + M)$ with zero backtracking | $O(M)$ for LPS array | Fast substring matching in projects |
| **Typo Tolerance** | Levenshtein Distance | $O(M \times N)$ 2D DP matrix | $O(M \times N)$ | Solves spelling mistakes in queries |
| **Recommendations** | Jaccard & Cosine | $O(K + V)$ vector dot product | $O(V)$ feature vector | Finding peers with similar skills |
| **Relevance Ranking** | Weighted Scoring Engine | $O(C \log C)$ candidate sort | $O(C)$ candidate records | Displays most relevant results first |

---

## 📡 REST API Endpoints

- `GET /api/students` - Retrieve all students (with department, year, CGPA, attendance filters)
- `GET /api/students/:id` - Get student details by ID or Roll Number
- `POST /api/students` - Add new student record (auto-indexes into Trie & Inverted Index)
- `PUT /api/students/:id` - Update existing student record (auto-resyncs indexes)
- `DELETE /api/students/:id` - Delete student record (auto-cleans indexes)
- `GET /api/search?q=...` - Smart ranked search with execution latency and score breakdown
- `GET /api/autocomplete?q=...` - Instant Trie prefix suggestion list
- `GET /api/dsa/fuzzy?q=...&threshold=2` - Levenshtein typo-tolerant fuzzy search
- `GET /api/dsa/kmp?pattern=...` - KMP substring search with LPS table
- `GET /api/dsa/similarity/:id` - Top-$K$ similar student peer recommendations
- `GET /api/dsa/benchmark?q=...` - Side-by-side Linear Scan vs Inverted Index benchmark
- `GET /api/stats` - System metrics, department breakdown, top skills, and index stats
