const fs = require('fs');
const path = require('path');
const Trie = require('../dsa/trie');
const InvertedIndex = require('../dsa/invertedIndex');
const KMP = require('../dsa/kmp');
const FuzzySearch = require('../dsa/fuzzy');
const SimilarityEngine = require('../dsa/similarity');
const Ranker = require('../dsa/ranker');

const DATA_FILE = path.join(__dirname, '..', 'data', 'students.json');

class StudentService {
  constructor() {
    this.students = [];
    this.trie = new Trie();
    this.invertedIndex = new InvertedIndex();
    this.init();
  }

  init() {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        this.students = JSON.parse(raw);
      } else {
        this.students = [];
      }
    } catch (err) {
      console.error('Failed to load students.json, initializing empty array:', err);
      this.students = [];
    }

    this.rebuildIndexes();
    console.log(`[StudentService] Loaded ${this.students.length} students. Rebuilt Trie (${this.trie.totalWords} words) and Inverted Index (${this.invertedIndex.totalIndexedTerms} indexed terms).`);
  }

  saveToFile() {
    try {
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.students, null, 2), 'utf8');
      return true;
    } catch (err) {
      console.error('Error saving students.json:', err);
      return false;
    }
  }

  rebuildIndexes() {
    this.trie = new Trie();
    this.invertedIndex = new InvertedIndex();

    for (const student of this.students) {
      // Index in Inverted Index
      this.invertedIndex.indexStudent(student);

      // Index in Trie for autocomplete
      this.trie.insert(student.name, student.id, 'Name');
      this.trie.insert(student.rollNo, student.id, 'Roll No');
      this.trie.insert(student.department, student.id, 'Department');

      if (Array.isArray(student.skills)) {
        student.skills.forEach(skill => {
          this.trie.insert(skill, student.id, 'Skill');
        });
      }

      if (Array.isArray(student.certifications)) {
        student.certifications.forEach(cert => {
          if (cert && cert.name) this.trie.insert(cert.name, student.id, 'Certification');
        });
      }
    }
  }

  getAllStudents(filters = {}) {
    let result = [...this.students];

    if (filters.department && filters.department !== 'All') {
      result = result.filter(s => s.department.toLowerCase() === filters.department.toLowerCase());
    }

    if (filters.minCgpa) {
      const minC = parseFloat(filters.minCgpa);
      if (!isNaN(minC)) {
        result = result.filter(s => s.cgpa >= minC);
      }
    }

    if (filters.minAttendance) {
      const minA = parseFloat(filters.minAttendance);
      if (!isNaN(minA)) {
        result = result.filter(s => s.attendance >= minA);
      }
    }

    if (filters.year && filters.year !== 'All') {
      const y = parseInt(filters.year, 10);
      if (!isNaN(y)) {
        result = result.filter(s => s.year === y);
      }
    }

    return result;
  }

  getStudentById(id) {
    return this.students.find(s => s.id === id || s.rollNo.toLowerCase() === (id || '').toLowerCase());
  }

  createStudent(data) {
    const newId = `STU-${1000 + this.students.length + 1}`;
    const newStudent = {
      id: newId,
      rollNo: (data.rollNo || '').trim().toUpperCase(),
      name: (data.name || '').trim(),
      department: (data.department || 'Computer Science & Engineering').trim(),
      year: parseInt(data.year, 10) || 1,
      semester: parseInt(data.semester, 10) || 1,
      cgpa: parseFloat(data.cgpa) || 8.0,
      attendance: parseInt(data.attendance, 10) || 85,
      email: (data.email || `${data.name ? data.name.toLowerCase().replace(/\s+/g, '.') : 'student'}@campus.edu`).trim(),
      phone: (data.phone || '+91 98451 00000').trim(),
      skills: Array.isArray(data.skills)
        ? data.skills
        : (data.skills || '').split(',').map(s => s.trim()).filter(s => s.length > 0),
      projects: Array.isArray(data.projects)
        ? data.projects
        : (data.projectTitle ? [{ title: data.projectTitle, description: data.projectDesc || '', techStack: [] }] : []),
      achievements: Array.isArray(data.achievements)
        ? data.achievements
        : (data.achievements || '').split(',').map(a => a.trim()).filter(a => a.length > 0),
      certifications: Array.isArray(data.certifications)
        ? data.certifications
        : typeof data.certifications === 'string'
          ? data.certifications.split(',').map(c => ({ name: c.trim(), issuer: 'Industry Partner', date: '2025', credentialId: 'CERT-' + Math.floor(100000 + Math.random() * 900000), verified: true })).filter(c => c.name.length > 0)
          : [],
      hackathons: Array.isArray(data.hackathons)
        ? data.hackathons
        : typeof data.hackathons === 'string'
          ? data.hackathons.split(',').map(h => ({ name: h.trim(), year: '2025', role: 'Participant / Innovator', project: 'Campus Innovation', award: 'Top Finalist 🎖️' })).filter(h => h.name.length > 0)
          : [],
      internships: Array.isArray(data.internships)
        ? data.internships
        : typeof data.internships === 'string'
          ? data.internships.split(',').map(i => ({ role: i.trim(), company: 'Tech Industry Partner', duration: 'Summer 2024', description: 'Practical engineering internship' })).filter(i => i.role.length > 0)
          : []
    };

    this.students.unshift(newStudent);
    this.saveToFile();
    this.rebuildIndexes();

    return newStudent;
  }

  updateStudent(id, updateData) {
    const index = this.students.findIndex(s => s.id === id);
    if (index === -1) return null;

    const existing = this.students[index];
    const updated = {
      ...existing,
      ...updateData,
      id: existing.id, // preserve ID
      skills: Array.isArray(updateData.skills)
        ? updateData.skills
        : typeof updateData.skills === 'string'
          ? updateData.skills.split(',').map(s => s.trim()).filter(s => s.length > 0)
          : existing.skills,
      achievements: Array.isArray(updateData.achievements)
        ? updateData.achievements
        : typeof updateData.achievements === 'string'
          ? updateData.achievements.split(',').map(a => a.trim()).filter(a => a.length > 0)
          : existing.achievements,
      certifications: Array.isArray(updateData.certifications)
        ? updateData.certifications
        : typeof updateData.certifications === 'string'
          ? updateData.certifications.split(',').map(c => ({ name: c.trim(), issuer: 'Industry Partner', date: '2025', credentialId: 'CERT-' + Math.floor(100000 + Math.random() * 900000), verified: true })).filter(c => c.name.length > 0)
          : existing.certifications || [],
      hackathons: Array.isArray(updateData.hackathons)
        ? updateData.hackathons
        : typeof updateData.hackathons === 'string'
          ? updateData.hackathons.split(',').map(h => ({ name: h.trim(), year: '2025', role: 'Participant', project: 'Capstone', award: 'Finalist 🎖️' })).filter(h => h.name.length > 0)
          : existing.hackathons || [],
      internships: Array.isArray(updateData.internships)
        ? updateData.internships
        : typeof updateData.internships === 'string'
          ? updateData.internships.split(',').map(i => ({ role: i.trim(), company: 'Tech Partner', duration: 'Summer 2024', description: 'Engineering Internship' })).filter(i => i.role.length > 0)
          : existing.internships || []
    };

    this.students[index] = updated;
    this.saveToFile();
    this.rebuildIndexes();

    return updated;
  }

  deleteStudent(id) {
    const index = this.students.findIndex(s => s.id === id);
    if (index === -1) return false;

    const removed = this.students.splice(index, 1)[0];
    this.saveToFile();
    this.rebuildIndexes();

    return removed;
  }

  autocomplete(prefix, limit = 8) {
    const startTime = process.hrtime.bigint();
    const suggestions = this.trie.searchPrefix(prefix, limit);
    const endTime = process.hrtime.bigint();
    const executionTimeMs = Number(endTime - startTime) / 1e6;

    return {
      query: prefix,
      suggestions,
      totalWordsInTrie: this.trie.totalWords,
      executionTimeMs: parseFloat(executionTimeMs.toFixed(3))
    };
  }

  smartSearch(query, filters = {}) {
    const startTime = process.hrtime.bigint();

    if (!query || query.trim() === '') {
      const all = this.getAllStudents(filters);
      return {
        results: all.map(s => ({ student: s, score: 100, breakdown: [{ reason: 'All records view', points: 100 }] })),
        query: '',
        totalResults: all.length,
        executionTimeMs: 0.1,
        algorithm: 'Full Listing'
      };
    }

    const cleanQuery = query.trim();
    // 1. Get filtered base candidates
    const candidateList = this.getAllStudents(filters);

    // 2. Rank using multi-criteria Ranker
    const { rankedResults, executionTimeMs: rankTime } = Ranker.rank(candidateList, cleanQuery);

    const endTime = process.hrtime.bigint();
    const totalTimeMs = Number(endTime - startTime) / 1e6;

    return {
      results: rankedResults,
      query: cleanQuery,
      totalResults: rankedResults.length,
      executionTimeMs: parseFloat(totalTimeMs.toFixed(3)),
      algorithm: 'Inverted Index + Multi-Factor Ranking Engine'
    };
  }

  fuzzySearch(query, threshold = 2) {
    return FuzzySearch.searchStudents(this.students, query, parseInt(threshold, 10) || 2);
  }

  kmpSearch(pattern, fields) {
    return KMP.searchStudents(this.students, pattern, fields);
  }

  findSimilar(studentId, topK = 5) {
    return SimilarityEngine.findSimilar(studentId, this.students, parseInt(topK, 10) || 5);
  }

  benchmark(query) {
    if (!query || query.trim() === '') {
      return { error: 'Query parameter is required for benchmarking' };
    }

    const q = query.trim().toLowerCase();

    // 1. Linear Scan Benchmark (Brute Force O(N * M))
    const linearStart = process.hrtime.bigint();
    let linearComparisons = 0;
    const linearMatches = [];

    for (const s of this.students) {
      linearComparisons++;
      let found = false;

      const fields = [
        s.name,
        s.rollNo,
        s.department,
        ...(s.skills || []),
        ...(s.projects || []).map(p => p.title),
        ...(s.achievements || [])
      ];

      for (const f of fields) {
        if (typeof f === 'string') {
          linearComparisons++;
          if (f.toLowerCase().includes(q)) {
            found = true;
            break;
          }
        }
      }

      if (found) {
        linearMatches.push(s.id);
      }
    }
    const linearEnd = process.hrtime.bigint();
    const linearTimeMicroseconds = Number(linearEnd - linearStart) / 1e3;

    // 2. Inverted Index Lookup (O(1) Hash Table Lookup)
    const indexStart = process.hrtime.bigint();
    let indexComparisons = 1; // 1 hash table lookup
    const indexResults = this.invertedIndex.search(q);
    const indexEnd = process.hrtime.bigint();
    const indexTimeMicroseconds = Number(indexEnd - indexStart) / 1e3;

    const speedup = linearTimeMicroseconds > 0 && indexTimeMicroseconds > 0
      ? (linearTimeMicroseconds / indexTimeMicroseconds).toFixed(1)
      : 'N/A';

    return {
      query: q,
      totalStudents: this.students.length,
      linearScan: {
        timeMicroseconds: parseFloat(linearTimeMicroseconds.toFixed(2)),
        timeMilliseconds: parseFloat((linearTimeMicroseconds / 1000).toFixed(4)),
        comparisons: linearComparisons,
        matchesCount: linearMatches.length,
        complexity: 'O(N × M)'
      },
      invertedIndex: {
        timeMicroseconds: parseFloat(indexTimeMicroseconds.toFixed(2)),
        timeMilliseconds: parseFloat((indexTimeMicroseconds / 1000).toFixed(4)),
        comparisons: indexComparisons,
        matchesCount: indexResults.length,
        complexity: 'O(1) amortized hash lookup'
      },
      speedupMultiplier: speedup,
      postingDetails: this.invertedIndex.getPostingDetails(q)
    };
  }

  authenticate(role, identifier, password) {
    const cleanRole = (role || 'student').toLowerCase();
    const cleanId = (identifier || '').trim().toLowerCase();
    const cleanPwd = (password || '').trim();

    if (cleanRole === 'admin') {
      if ((cleanId === 'admin' || cleanId === 'admin@campus.edu') && (cleanPwd === 'admin123' || cleanPwd === 'admin')) {
        return {
          success: true,
          role: 'admin',
          user: {
            username: 'admin',
            name: 'Campus System Administrator',
            email: 'admin@campus.edu',
            role: 'admin'
          }
        };
      }
      return { success: false, error: 'Invalid admin username or password (default: admin / admin123)' };
    }

    if (cleanRole === 'student') {
      // Look up student by rollNo or email
      const student = this.students.find(s =>
        s.rollNo.toLowerCase() === cleanId ||
        s.email.toLowerCase() === cleanId ||
        s.id.toLowerCase() === cleanId
      );

      if (!student) {
        return { success: false, error: `Student with Roll No / Email "${identifier}" not found in database.` };
      }

      // Allow password 'student123' or matching roll number
      if (cleanPwd === 'student123' || cleanPwd.toLowerCase() === student.rollNo.toLowerCase()) {
        return {
          success: true,
          role: 'student',
          student
        };
      }

      return { success: false, error: 'Invalid student password (default: student123 or your Roll Number)' };
    }

    return { success: false, error: 'Invalid authentication role' };
  }

  getDashboardStats() {
    const total = this.students.length;
    if (total === 0) {
      return {
        totalStudents: 0,
        averageCgpa: 0,
        averageAttendance: 0,
        departments: {},
        topSkills: []
      };
    }

    const deptCounts = {};
    const skillCounts = {};
    let totalCgpa = 0;
    let totalAttendance = 0;
    let totalProjects = 0;

    for (const s of this.students) {
      deptCounts[s.department] = (deptCounts[s.department] || 0) + 1;
      totalCgpa += s.cgpa || 0;
      totalAttendance += s.attendance || 0;
      totalProjects += (s.projects || []).length;

      (s.skills || []).forEach(sk => {
        skillCounts[sk] = (skillCounts[sk] || 0) + 1;
      });
    }

    const sortedSkills = Object.entries(skillCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([name, count]) => ({ name, count }));

    return {
      totalStudents: total,
      averageCgpa: parseFloat((totalCgpa / total).toFixed(2)),
      averageAttendance: parseFloat((totalAttendance / total).toFixed(1)),
      totalProjects,
      departments: deptCounts,
      topSkills: sortedSkills,
      dsaStats: {
        trieWords: this.trie.totalWords,
        indexedTerms: this.invertedIndex.totalIndexedTerms,
        uniqueTokens: this.invertedIndex.index.size
      }
    };
  }
}

// Singleton instance
module.exports = new StudentService();
