/**
 * Comprehensive Student Dataset Generator (100+ Realistic University Records)
 * Generates rich records with Certifications, Hackathons, Internships, Projects & Skills
 */

const fs = require('fs');
const path = require('path');

const firstNames = [
  "Rupesh", "Aarav", "Ananya", "Vikram", "Priya", "Rohan", "Aditya", "Siddharth",
  "Meera", "Kavya", "Harsh", "Tanvi", "Naveen", "Sneha", "Arjun", "Divya",
  "Rahul", "Bhavya", "Karthik", "Pooja", "Mohit", "Isha", "Rishi", "Deepika",
  "Tushar", "Sanjana", "Akash", "Riya", "Varun", "Shruti", "Gautam", "Neha",
  "Pranav", "Swati", "Abhishek", "Kritika", "Suresh", "Pooja", "Manish", "Simran",
  "Kunal", "Pallavi", "Vivek", "Shreya", "Nikhil", "Aishwarya", "Ashwin", "Pooja",
  "Karan", "Gayatri"
];

const lastNames = [
  "Naidu", "Sharma", "Iyer", "Malhotra", "Nair", "Deshmukh", "Verma", "Rao",
  "Krishnan", "Patel", "Vardhan", "Gupta", "Reddy", "Mukhopadhyay", "Singhal", "Nambiar",
  "Chawla", "Agarwal", "Sundaram", "Hegde", "Bansal", "Kulkarni", "Kapoor", "Sen",
  "Saxena", "Choudhury", "Bhattacharya", "Menon", "Joshi", "Pillai", "Mishra", "Banerjee"
];

const departments = [
  { code: "CS", name: "Computer Science & Engineering" },
  { code: "AI", name: "Artificial Intelligence & Data Science" },
  { code: "IT", name: "Information Technology" },
  { code: "EC", name: "Electronics & Communication" },
  { code: "EE", name: "Electrical & Electronics" },
  { code: "ME", name: "Mechanical Engineering" }
];

const skillsPool = {
  "Computer Science & Engineering": [
    "JavaScript", "Node.js", "Python", "C++", "Algorithms", "React", "Docker", "PostgreSQL",
    "Go", "System Design", "Redis", "Distributed Systems", "Rust", "GraphQL", "Linux", "Kubernetes"
  ],
  "Artificial Intelligence & Data Science": [
    "Python", "Machine Learning", "Deep Learning", "PyTorch", "TensorFlow", "Computer Vision",
    "NLP", "Transformers", "Data Science", "Pandas", "Scikit-Learn", "FastAPI", "GenAI", "LangChain"
  ],
  "Information Technology": [
    "Java", "Spring Boot", "React", "Node.js", "TypeScript", "AWS", "Cloud Computing",
    "Microservices", "Docker", "PostgreSQL", "MongoDB", "DevOps", "Kafka", "Flutter", "REST APIs"
  ],
  "Electronics & Communication": [
    "Embedded Systems", "C++", "IoT", "Arduino", "Raspberry Pi", "VLSI Design", "Verilog",
    "FPGA", "Signal Processing", "Wireless Communications", "5G", "MATLAB", "PCB Design"
  ],
  "Electrical & Electronics": [
    "Power Systems", "MATLAB", "Simulink", "Solar Energy", "Microcontrollers", "Power Electronics",
    "Control Systems", "Embedded C", "Inverter Design", "Electric Vehicles", "Battery Management"
  ],
  "Mechanical Engineering": [
    "AutoCAD", "SolidWorks", "Finite Element Analysis", "CFD", "Ansys Fluent", "Robotics",
    "3D Printing", "Thermodynamics", "Aerodynamics", "Heat Transfer", "MATLAB", "ROS2"
  ]
};

const certificationsPool = [
  { name: "AWS Certified Solutions Architect - Associate", issuer: "Amazon Web Services", credentialId: "AWS-SAA-882914", verified: true },
  { name: "Google Associate Cloud Engineer", issuer: "Google Cloud", credentialId: "GCP-ACE-502194", verified: true },
  { name: "Oracle Certified Professional: Java SE 17 Developer", issuer: "Oracle University", credentialId: "OCP-JAVA-3391", verified: true },
  { name: "Certified Kubernetes Administrator (CKA)", issuer: "Cloud Native Computing Foundation", credentialId: "CKA-774012", verified: true },
  { name: "DeepLearning.AI Machine Learning Specialization", issuer: "Coursera & Stanford Online", credentialId: "COURSERA-ML-9920", verified: true },
  { name: "Meta Front-End Developer Professional Certificate", issuer: "Meta", credentialId: "META-FED-48192", verified: true },
  { name: "Microsoft Certified: Azure Fundamentals (AZ-900)", issuer: "Microsoft", credentialId: "MS-AZ900-11029", verified: true },
  { name: "NVIDIA Deep Learning Institute: Fundamentals of Computer Vision", issuer: "NVIDIA DLI", credentialId: "NV-DLI-66190", verified: true },
  { name: "Cisco Certified Network Associate (CCNA)", issuer: "Cisco Systems", credentialId: "CSCO-CCNA-20491", verified: true },
  { name: "HashiCorp Certified: Terraform Associate", issuer: "HashiCorp", credentialId: "HC-TERRA-8401", verified: true }
];

const hackathonsPool = [
  { name: "National Smart Campus Hackathon 2025", role: "Team Lead & System Architect", project: "Smart Campus Student Record Engine", award: "1st Prize Winner 🏆", year: "2025" },
  { name: "Smart India Hackathon (SIH 2024)", role: "Full Stack & Algorithm Developer", project: "Decentralized Academic Degree Verification", award: "National Finalist 🎖️", year: "2024" },
  { name: "ETHIndia Web3 Hackathon 2024", role: "Smart Contract Engineer", project: "Zero-Knowledge Academic Credentials on zkEVM", award: "Best Protocol Innovation 🥇", year: "2024" },
  { name: "Google Solution Challenge 2024", role: "AI & ML Specialist", project: "Classroom Multilingual Speech Transcriber", award: "Global Top 100 Finalist 🌍", year: "2024" },
  { name: "IIT TechFest Annual CodeSprint 2024", role: "Competitive Programmer", project: "High-Throughput SIMD Vector Query Engine", award: "Grand Winner (Rank #1) 🏆", year: "2024" },
  { name: "Inter-College Robotics Challenge 2024", role: "Embedded Firmware Engineer", project: "Autonomous Document Delivery Rover", award: "Best Hardware Innovation 🥇", year: "2024" },
  { name: "National Cyber Security CTF 2025", role: "Security Researcher", project: "Real-Time Campus Network Intrusion Detection", award: "1st Place Winner 🏆", year: "2025" },
  { name: "AngelHack Global Campus Series", role: "Lead Frontend Engineer", project: "Campus Alumni Mentorship Network", award: "Runner-Up 🥈", year: "2024" }
];

const internshipsPool = [
  { role: "Software Engineering Intern", company: "Google Summer of Code / Apache Foundation", duration: "May 2024 - Aug 2024", description: "Contributed SIMD-vectorized execution kernels for in-memory analytical query processing." },
  { role: "Machine Learning Research Intern", company: "Centre for Artificial Intelligence & Robotics", duration: "Jan 2024 - June 2024", description: "Fine-tuned multilingual transformer models for automatic speech recognition and real-time captioning." },
  { role: "Cloud Infrastructure & DevOps Intern", company: "Amazon Web Services (AWS) Partner Cohort", duration: "June 2024 - Aug 2024", description: "Designed automated CI/CD pipelines deploying microservices across Kubernetes clusters." },
  { role: "Embedded Systems Trainee", company: "Texas Instruments University Program", duration: "July 2024 - Sept 2024", description: "Programmed low-latency RTOS firmware for ARM Cortex-M microcontrollers and IoT energy sensors." },
  { role: "Full Stack Engineering Intern", company: "EdTech Innovations India", duration: "Jan 2024 - May 2024", description: "Developed scalable interactive assessment engine executing untrusted student code in Docker sandboxes." }
];

const projectTemplates = [
  { title: "Smart Campus Student Record Engine", desc: "High-performance university database with DSA indexed search, Trie autocomplete, and Levenshtein typo tolerance.", tech: ["Node.js", "Express", "Data Structures"] },
  { title: "Distributed Task Scheduler", desc: "Fault-tolerant queue scheduler using Redis and round-robin load distribution.", tech: ["Node.js", "Redis", "Docker"] },
  { title: "Automated Attendance via Facial Recognition", desc: "CNN-based biometric attendance system operating over IP cameras with 98.4% accuracy.", tech: ["Python", "OpenCV", "PyTorch", "FastAPI"] },
  { title: "Academic Question Answering Bot", desc: "RAG-powered conversational assistant for university syllabus and lecture transcripts.", tech: ["LangChain", "HuggingFace", "Python"] },
  { title: "Student Dropout Risk Predictor", desc: "Ensemble learning model analyzing grade trends and attendance to predict at-risk students.", tech: ["Python", "XGBoost", "Streamlit"] },
  { title: "Microservices University Portal", desc: "Scalable student grading and registration microservices deployed on AWS EKS with Prometheus monitoring.", tech: ["Go", "Kubernetes", "AWS"] },
  { title: "Campus Smart Energy Grid", desc: "IoT wireless sensor network monitoring power consumption in university classrooms in real time.", tech: ["ESP32", "C++", "MQTT"] },
  { title: "Autonomous Campus Delivery Rover", desc: "Mechanical chassis and obstacle-avoiding rover designed for inter-department document delivery.", tech: ["SolidWorks", "ROS2", "Python"] },
  { title: "High-Throughput Key-Value Store", desc: "LSM-tree based persistent storage engine with WAL logging and write-optimized performance.", tech: ["C++", "Multithreading", "Linux"] }
];

const achievementTemplates = [
  "1st Prize at National Smart Campus Hackathon 2025",
  "Author of open-source DSA utility library with 1k+ stars",
  "Published IEEE paper on edge computer vision",
  "Dean's List of Academic Excellence (3 consecutive years)",
  "Top 10 Finalist in Smart India Hackathon",
  "Winner at Inter-College Robotics Challenge 2024",
  "Candidate Master on Codeforces (Rating 1940)",
  "Gold Medalist in Department Academic Toppers List"
];

function generateStudents(count = 100) {
  const students = [];

  // STU-1001: Rupesh Naidu
  students.push({
    id: "STU-1001",
    rollNo: "21CS101",
    name: "Rupesh Naidu",
    department: "Computer Science & Engineering",
    year: 4,
    semester: 7,
    cgpa: 9.45,
    attendance: 94,
    email: "rupesh.naidu@campus.edu",
    phone: "+91 98451 22301",
    skills: ["JavaScript", "Node.js", "Python", "Algorithms", "React", "Docker", "PostgreSQL", "Data Structures"],
    certifications: [
      { name: "AWS Certified Solutions Architect - Associate", issuer: "Amazon Web Services", credentialId: "AWS-SAA-882914", verified: true, date: "2024" },
      { name: "Certified Kubernetes Administrator (CKA)", issuer: "Cloud Native Computing Foundation", credentialId: "CKA-774012", verified: true, date: "2024" },
      { name: "Meta Front-End Developer Professional Certificate", issuer: "Meta", credentialId: "META-FED-48192", verified: true, date: "2023" }
    ],
    hackathons: [
      { name: "National Smart Campus Hackathon 2025", role: "Team Lead & System Architect", project: "Smart Campus Student Record Engine", award: "1st Prize Winner 🏆", year: "2025" },
      { name: "Smart India Hackathon (SIH 2024)", role: "Backend & Algorithm Developer", project: "Decentralized Degree Verification", award: "National Finalist 🎖️", year: "2024" },
      { name: "ETHIndia Web3 Hackathon 2024", role: "Full Stack Engineer", project: "Zk-Proof Credentials System", award: "Best Campus Protocol 🥇", year: "2024" }
    ],
    internships: [
      { role: "Software Engineering Intern", company: "Google Summer of Code / Apache Foundation", duration: "May 2024 - Aug 2024", description: "Engineered SIMD query parsing and cache optimizations for distributed database engine." }
    ],
    projects: [
      {
        title: "Smart Campus Student Record Engine",
        description: "High-performance university database with DSA indexed search, Trie autocomplete, and Levenshtein typo tolerance.",
        techStack: ["Node.js", "Express", "Tailwind CSS", "Data Structures"]
      },
      {
        title: "Distributed Task Scheduler",
        description: "Fault-tolerant queue scheduler using Redis and round-robin load distribution.",
        techStack: ["Node.js", "Redis", "Docker"]
      }
    ],
    achievements: [
      "1st Prize at National Smart Campus Hackathon 2025",
      "Author of open-source DSA utility library with 1k+ stars"
    ]
  });

  for (let i = 2; i <= count; i++) {
    const id = `STU-${1000 + i}`;
    const fName = firstNames[(i * 7) % firstNames.length];
    const lName = lastNames[(i * 11) % lastNames.length];
    const name = `${fName} ${lName}`;

    const deptObj = departments[(i - 1) % departments.length];
    const department = deptObj.name;
    const year = ((i % 4) + 1);
    const semester = (year * 2) - (i % 2);
    const batchYear = 25 - year;
    const rollNo = `${batchYear}${deptObj.code}${String(100 + (i % 900)).padStart(3, '0')}`;

    const cgpa = parseFloat((7.2 + ((i * 17) % 265) / 100).toFixed(2));
    const attendance = 75 + ((i * 23) % 24);

    const email = `${fName.toLowerCase()}.${lName.toLowerCase()}${i % 5 === 0 ? i : ''}@campus.edu`;
    const phone = `+91 ${98000 + (i * 137)} ${String(10000 + (i * 353)).slice(-5)}`;

    // Skills
    const pool = skillsPool[department];
    const skillsCount = 4 + (i % 3);
    const skills = [];
    for (let s = 0; s < skillsCount; s++) {
      const sk = pool[(i + s * 3) % pool.length];
      if (!skills.includes(sk)) skills.push(sk);
    }

    // Certifications (2-3 certs)
    const certifications = [];
    const certCount = 1 + (i % 3);
    for (let c = 0; c < certCount; c++) {
      const baseCert = certificationsPool[(i * 3 + c * 2) % certificationsPool.length];
      certifications.push({
        ...baseCert,
        date: String(2023 + ((i + c) % 3))
      });
    }

    // Hackathons (1-2 hackathons)
    const hackathons = [];
    const hackCount = 1 + (i % 2);
    for (let h = 0; h < hackCount; h++) {
      const baseHack = hackathonsPool[(i * 2 + h * 3) % hackathonsPool.length];
      hackathons.push({
        ...baseHack,
        year: String(2024 + (h % 2))
      });
    }

    // Internships (1 internship for year >= 2)
    const internships = [];
    if (year >= 2) {
      const baseIntern = internshipsPool[(i * 3) % internshipsPool.length];
      internships.push(baseIntern);
    }

    // Projects
    const proj1 = projectTemplates[(i * 3) % projectTemplates.length];
    const projects = [{
      title: proj1.title,
      description: proj1.desc,
      techStack: proj1.tech
    }];

    // Achievements
    const ach1 = achievementTemplates[(i * 5) % achievementTemplates.length];
    const achievements = [ach1];

    students.push({
      id,
      rollNo,
      name,
      department,
      year,
      semester,
      cgpa,
      attendance,
      email,
      phone,
      skills,
      certifications,
      hackathons,
      internships,
      projects,
      achievements
    });
  }

  return students;
}

const count = 100;
const generated = generateStudents(count);
const outputPath = path.join(__dirname, 'students.json');
fs.writeFileSync(outputPath, JSON.stringify(generated, null, 2), 'utf8');

console.log(`[Seed] Successfully generated and wrote ${generated.length} student records with Certifications & Hackathons to ${outputPath}`);
