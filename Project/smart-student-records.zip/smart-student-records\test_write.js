async function check() {
  const res = await fetch('http://localhost:3000/api/students/STU-1001');
  const json = await res.json();
  const s = json.data;
  console.log('Student:', s.name, s.rollNo);
  console.log('Certifications:', s.certifications.length, s.certifications.map(c => c.name));
  console.log('Hackathons:', s.hackathons.length, s.hackathons.map(h => `${h.name} (${h.award})`));
  console.log('Internships:', s.internships.length, s.internships.map(i => `${i.role} at ${i.company}`));
}
check().catch(console.error);

