/**
 * Test authentication endpoints for Admin and Student portals
 */

const assert = require('assert');

async function testAuth() {
  console.log('Testing Authentication Endpoints...');

  // 1. Admin Login
  const adminRes = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ role: 'admin', identifier: 'admin', password: 'admin123' })
  });
  const adminJson = await adminRes.json();
  assert(adminJson.success === true, 'Admin login should succeed');
  assert(adminJson.role === 'admin', 'Role should be admin');
  console.log(' [PASS] Admin Login successful:', adminJson.user.name);

  // 2. Student Login (Rupesh Naidu - 21CS101)
  const studentRes = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ role: 'student', identifier: '21CS101', password: 'student123' })
  });
  const studentJson = await studentRes.json();
  assert(studentJson.success === true, 'Student login should succeed');
  assert(studentJson.role === 'student', 'Role should be student');
  assert(studentJson.student.name === 'Rupesh Naidu', 'Student name should match');
  console.log(' [PASS] Student Login successful:', studentJson.student.name, 'Roll:', studentJson.student.rollNo);
  console.log('        Student Skills:', studentJson.student.skills.length, 'Projects:', studentJson.student.projects.length);

  // 3. Invalid credentials test
  const badRes = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ role: 'admin', identifier: 'admin', password: 'wrong' })
  });
  const badJson = await badRes.json();
  assert(badJson.success === false, 'Invalid admin login should fail');
  console.log(' [PASS] Invalid credentials properly rejected');

  console.log('\nALL AUTHENTICATION TESTS PASSED! ✅');
}

testAuth().catch(err => {
  console.error('Auth test failed:', err);
  process.exit(1);
});
